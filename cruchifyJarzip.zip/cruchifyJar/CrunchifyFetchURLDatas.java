import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;
import com.pi4j.io.gpio.RaspiPin;
/**
* @author Crunchify.com
*/
public class CrunchifyFetchURLDatas {
  
//String backupfanon="N";
    public static void main(String[] args) {
       
        
        try {
            //System.setProperty("http.proxyHost", "my.proxyhost.com");
           // System.setProperty("http://3.234.164.81:80", "8080");
            final GpioController gpio = GpioFactory.getInstance();
            final GpioPinDigitalOutput pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_05, "pin", PinState.HIGH);
            for(;;){ 
                Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("3.234.164.81", 80));
            URLConnection data =  new URL("https://fsm-incident-microservice-prod.run.aws-usw02-pr.ice.predix.io/fetchStatusOfPrimaryFan").openConnection(proxy);
            /* HttpGet get= new HttpGet(url);
             HttpClient client= HttpClientBuilder.create().build();
             HttpHost proxy=new HttpHost("3.234.164.81",8080,"http");RequestConfig config =RequestConfig.custom().setProxy(proxy).build();
             get.setConfig(config);
             get.set(config);
             HttpResponse response =client.execute(get);*/
            StringBuilder content = new StringBuilder();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(data.getInputStream()));
                       
            String stopactivity="N";
            String backupfanon="N";
            String status="";
            Thread.sleep(2500); 
            while (null != (status = bufferedReader.readLine())) {
                System.out.println("Status-------"+status);
             
                if(status.equals("N")){
                    System.out.println("Status is N writing 1 to pin");
                    //GPIO_SET=1;
                pin.low();
                }
                else{
                    System.out.println("Status is Y writing 0 to pin");
                   // GPIO_SET=0;
                  pin.high();
                    //backupfanon="N";
                                
                }
            }
            }
                       
               /* if(stopactivity=="N"){
                        pin.pulse(5000, true);
                //   setTimeout(periodicActivity,5000);
               }*/
              }
       
                catch (Exception ex) {
            ex.printStackTrace();
        }
         //  }
      //  }
         
}
}
 