sudo java -jar cruchifyJar.jar
