import { AbstractControl, ValidationErrors } from "@angular/forms";

export class CustomValidators{
   static  canNotContainSpace(control:AbstractControl):ValidationErrors{
        if((control.value as string).includes(" "))
          return {canNotContainSpace : true};

        return null;

    }
}