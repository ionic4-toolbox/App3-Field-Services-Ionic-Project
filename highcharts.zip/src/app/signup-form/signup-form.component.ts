import { CustomValidators } from './custom.validators';
import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent {
  form = new FormGroup({
   userName : new FormControl('',[
     Validators.required,
     Validators.minLength(3),
     CustomValidators.canNotContainSpace]),
   password : new FormControl('',Validators.required)
  });

  get userName(){
    return this.form.get('userName');
  }


  get password(){
    return this.form.get('password');
  }

}
