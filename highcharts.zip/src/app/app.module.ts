import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { CourseComponent } from './course/course.component';
import { CoursesService } from './courses.service';
import { SummaryPipe } from './Summary.pipe';
import { FavouriteComponent } from './favourite/favourite.component';
import { SignupFormComponent } from './signup-form/signup-form.component';
import { ChartModule } from 'angular2-highcharts';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { GaugeChartComponent } from './gauge-chart/gauge-chart.component';
import { ColumnChartComponent } from './column-chart/column-chart.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { CombinationChartComponent } from './combination-chart/combination-chart.component';

declare var require : any;
@NgModule({
  declarations: [
    AppComponent,
    SignupFormComponent,
    CourseComponent,
    SummaryPipe,
    FavouriteComponent,
    GaugeChartComponent,
    ColumnChartComponent,
    PieChartComponent,
    CombinationChartComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule, 
    ChartModule.forRoot(require('highcharts'),require('highcharts/highcharts-more')
		,require('highcharts/modules/solid-gauge'),require('highcharts/modules/exporting'),
    require('highcharts/modules/drilldown'))
  ],
  providers: [CoursesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);
