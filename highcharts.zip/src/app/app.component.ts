import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{

  gaugeValue: number;
  arrayValues:number;

  constructor() {
}

ngOnInit(){
 setInterval(() => { this.changeInit(); }, 5000);
 setInterval(() => { this.changeColumn(); }, 5000);
}

changeInit(){
    let inc = Math.floor(Math.random()*200 + 1);
    this.gaugeValue = inc;
}
changeColumn(){
  let inc = Math.floor(Math.random()*200 + 1);
    this.arrayValues = inc;
}

}