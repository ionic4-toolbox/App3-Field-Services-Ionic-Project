import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-column-chart',
  templateUrl: './column-chart.component.html',
  styleUrls: ['./column-chart.component.css']
})
export class ColumnChartComponent implements OnInit,OnChanges {

  @Input()
  arrayValues1:Number[];
  chart: any;
  options: any;
  ngOnInit() {
  }

  ngOnChanges(){
    this.battleInit();
  }

  constructor() {
    this.options = {
      chart: {
        type: 'column'
      },
      pane: {
        center: ['50%', '85%'],
        size: '40%',
        startAngle: -90,
        endAngle: 90,

        background: {
          backgroundColor: 'lightgrey',
          innerRadius: '60%',
          outerRadius: '100%',
          shape: 'arc'
        }
      },
      text: 'Monthly Average Rainfall',
      subtitle : {
        text: 'Source: WorldClimate.com'  
     },
     xAxis : {
      categories: ['Jan','Feb','Mar','Apr','May','Jun','Jul',
         'Aug','Sep','Oct','Nov','Dec'],
      crosshair: true
   },
      tooltip: {
        enabled: true,
        headerFormat: '<span style = "font-size:10px">{point.key}</span><table>',
               pointFormat: '<tr><td style = "color:{series.color};padding:0">{series.name}: </td>' +
                  '<td style = "padding:0"><b>{point.y:.1f} mm</b></td></tr>',
               footerFormat: '</table>',
               shared: true,
               useHTML: true
      },
      yAxis: {
        min: 0,
               title: {
                  text: 'Rainfall (mm)'         
               } 
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
       }
      },
      credits: {
        enabled: false
      },
      series: [{
        name: 'Tokyo',
        data: [0]
     }, 
     {
        name: 'New York',
        data: [0]
     }]
      }
    }
  saveInstance(chartInstance) {
    this.chart = chartInstance;
  }
  battleInit() {
    if(this.chart != undefined){
    let point = this.chart.series[0];
    // point.array.forEach(element => {
      
    // });
    //point.update(this.arrayValues1);
    point.setData([129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4, 29.9, 71.5, 106.4])
    console.log('arrayValues',point);
  //   this.chart.addSeries({                        
  //     name: "India",
  //     data: [129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4, 29.9, 71.5, 106.4]
  // })
}
  }

}
