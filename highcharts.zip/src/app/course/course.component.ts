import { Component, OnInit } from '@angular/core';
import { CoursesService } from './../courses.service';

/*******   
Property binding : We put a property between square brackets and bind it to a field of a class.
Dom- is a model of objects that represents the structure of a document. a tree of objects in memory
Html - is a markup language we used to represent dom in text. Browser parses  the html into dom objects.
dom  can be created usong javascript also but using html is far simpler

Most of the html attributes has an one to one mapping with dom properties

some exceptions being - 

html attr don't have a representative in dom-  "Colspan" attr of td of table - we need to use [attr.colspan] in html 
property to let angualr know that it is not som property we are binding instead we are binding to html attribute.
dom attrinutes don't have a reprwsentative in html- "textValue" of h tags


oevents- all the events of an element tends to bubble up to its parent element sp if we put a button inside a div and both 
button and div has on click events and button is clicked , the onclick method of button as well as div both will be called
this is called event bubbling. to stop this we call "$event.stopPropragation() on the button event handler."


two way binding- banana in a box. ngModel directive is used  
 */
@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {

  courses: any[];
  email:string="myemail@domain,com";
  text:string="hello h1";
  colspan:number=2;
  text1:string="1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10,1,2,3,4,5,6,7,9,10"
  constructor(_service : CoursesService) { 
     this.courses = _service.getCourses();
  }
  isActive = true;

  onDivClick($event){
    console.log("div clicked",$event);

  }

  onButtonClick($event){
    $event.stopPropagation();
    console.log("button clicked",$event);
  }

  onKeyUP(){
    console.log(this.email);
  }
  ngOnInit() {
  }

}
