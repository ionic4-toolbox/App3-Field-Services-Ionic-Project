import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent implements OnInit, OnChanges {

  chart: any;
  options: any;

  @Input()
  pieValue: Number;

  ngOnChanges(){
    this.changeValue();
  }

  constructor() {
    this.options = {
        chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie'
        },
        title: {
        text: "Expenses"
      },
        tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:&pound;%01.2f}</b> of total<br/>'
      },
        plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: "pointer",
          dataLabels: {
            enabled: false
          },
          showInLegend: true
        }
      },
        series: [{
        type: 'pie',
        name: "Groups",
        colorByPoint: true,
        data: [{
          name: "Science",
          y: 0,
          drilldown: "hi"
        },
        {
          name: "Arts",
          y: 0,
          drilldown: 5
        },
        {
          name: "Comarts",
          y: 0,
          drilldown: null
        }
            ]
      }],
      drilldown: {
        series: [{
          name: "Science",
          id: "hi",
          data: [
            ["Physical Science", 61.3],
            ["Chemistry", 78.66],
          ]
        },
        {
          name: "Arts",
          id: 5,
          data: [
            ["History", 61.3],
            ["Geography", 90.66],
          ]
        }
      ]
      }
    };
}

saveInstance(chartInstance) {
  this.chart = chartInstance;
}

changeValue(){
  let point = this.chart.series[0];
  point.setData([4,5,6]);
//   let drillDown = [{
//     name: "Science",
//     id: "hi",
//     data: [
//       ["Math", 50],
//       ["Engg", 50],
//     ]
//   },
//   {
//     name: "Arts",
//     id: 5,
//     data: [
//       ["History", 61.3],
//       ["Geography", 90.66],
//     ]
//   }
// ]
  console.log("drill down",this.chart.options.drilldown.series[0].data) ;
  let newDrillDowns = {
    name: "Science",
    id: 'hi',
    data: [
        ['Cat1', 4],
        ['Cat2', 2],
        ['Cat3', 1]
    ]};
    this.chart.options.drilldown.series[0] = newDrillDowns;
  console.log("drill down 2",this.chart.options.drilldown.series[0].data) ;
}
drillDown(event)
{
console.log("in drill down",event);
}

  ngOnInit() {
  }



}
