import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-combination-chart',
  templateUrl: './combination-chart.component.html',
  styleUrls: ['./combination-chart.component.css']
})
export class CombinationChartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
