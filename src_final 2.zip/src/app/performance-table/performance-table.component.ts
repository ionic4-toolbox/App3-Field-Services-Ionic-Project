

import { Component, OnInit, Input, OnChanges, EventEmitter } from '@angular/core';

import { MyServiceService } from './../service/my-service.service';
import { MatTable, MatTableDataSource } from '@angular/material';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';

import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material';
import { AppComponent } from 'src/app/app.component';

@Component({
  selector: 'app-performance-table',
  templateUrl: './performance-table.component.html',
  styleUrls: ['./performance-table.component.css']
})
export class PerformanceTableComponent implements OnInit {



  tb2: any;
  tb1: any;
  alertCleaning: any;
  gaugePost: any = [];
  gaugepost;
assetId: any;

  tableData: any;
  tableData2: any;
  finalData1: any = [];
  finalData2: any = [];

  finalTableData;
  final1: any = [];
  final2: any;
  public show = false;

  tags = [];
  tagsData: any = {};
  tagsArr: any = [];

  gaugeInv1Value = [];
  gaugeInv2Value = [];
  icon1 = false;
  icon2 = false;
  todaysEnergy: any;
  energy1:any;
  energy2:any;
  GaugeInv1 = [];
  GaugeInv2 = [];
  alert;
  guageArray: any;
  gaugeType = 'semi';
  foreground = 'rgb(90, 190, 206)';
  background = '#526069';
  form: FormGroup;

panel1Name:any='Inverter 1';
panel2Name:any='Inverter 2';
panel2hide=true;

  reminder;
  alertId;
  // dataSource = new UserDataSource(this.userService);
  displayedColumns = ['avgValue', 'thresholdMin', 'unit', 'ratedValue', 'sensorName', 'effeciency',
    'reliability', 'threshold'];
  constructor(private appcomponent:AppComponent,private userService: MyServiceService, iconRegistry: MatIconRegistry, sanitizer: DomSanitizer, private fb: FormBuilder) {
    iconRegistry.addSvgIcon(
      'warning',
      sanitizer.bypassSecurityTrustResourceUrl('assets/img/examples/sharp-warning-24px.svg'));

    iconRegistry.addSvgIcon(
      'check-circle',

      sanitizer.bypassSecurityTrustResourceUrl('assets/img/examples/sharp-check_circle-24px.svg'));


    this.userService.currentJobName.subscribe((message: any) => {

      this.onFilterClick(message);

    });

  }


  ngOnInit() {

  }

  onFilterClick(event) {



    // this.appcomponent.startLoading();
    console.log('event', event );
    this.assetId = event;
    this.getTodaysEnergy();
    this.gaugeData();
    this.getData();
     this.getAlertData();

    console.log('event asset id', this.assetId);


    if(this.assetId=='Everglades'){

      this.panel1Name='Panel 1';
      this.panel2Name='Panel 2';
      

    }else if(this.assetId=='Wind-Mill'){
      this.panel1Name='Wind-Mill';
      this.panel2hide=false;
    }else{
      this.panel1Name='Inverter 1';
      this.panel2Name='Inverter 2';
    }


  }


  getTodaysEnergy() {

    this.userService.getEnergy(this.assetId)
      .subscribe(
        returnData => {
          this.todaysEnergy = returnData;
          console.log('todaysEnergy', this.todaysEnergy);
          if (this.todaysEnergy.length !== 0) {
            console.log('todaysEnergy', this.todaysEnergy);

            if(this.assetId !== 'Wind-Mill'){

            

            this.energy1 = this.todaysEnergy['0']['energy'];
            this.energy2 = this.todaysEnergy['1']['energy'];
            console.log('energy1', this.energy1);
          } else{
            this.energy1=this.todaysEnergy['0']['powerFactor'];
            console.log('energy1', this.energy1)
          }
         
          }
        }
      );



  }



  getAlertData() {
    this.userService.getAlert()
      .subscribe(
        returnData => {
          this.alert = returnData;
           console.log('alert.length', this.alert);

           
          for (let i = 0; i <= 5; i++) {

            if (this.alert[i].assetName === this.assetId) {

              this.alertCleaning = this.alert[i].data.cleaningActivity;
              break;

            }
          }
        }
      
      );
      this.appcomponent.stopLoading();
  }


  gaugeData() {
    this.userService.getGauge(this.assetId)
      .subscribe(
        returnData => {
          this.guageArray = returnData;
          this.GaugeInv1 = [];
          this.GaugeInv2 = [];
          this.tags = [];
          this.gaugeInv1Value = [];
          this.gaugeInv2Value = [];
          if (this.guageArray.length !== 0) {


            for (let i = 0; i < 6; i++) {


              this.tags.push(this.guageArray[i].sensorTag);
            }
            this.tagsArr = [];
            for (let ind = 0; ind < this.tags.length; ind++) {
              this.tagsArr.push({
                'name': this.tags[ind]
              });
            }
            console.log('gauge inv2', this.GaugeInv2);
            console.log(this.tagsArr);
            this.tagsData.tags = this.tagsArr;

            console.log('tagData', this.tagsData);

            this.userService.postGauge(this.tagsData)
              .subscribe(
                returnData1 => {
                  this.gaugepost = returnData1;

                  console.log( this.gaugepost.tags[0].results[0].values[0][1]);


                  for (let i = 0; i < 3; i++) {



                    const obj = {
                      'sensorRealName': this.guageArray[i].sensorRealName,
                      'unit': this.guageArray[i].unit,
                      'thresholdMax': this.guageArray[i].thresholdMax,
                      'currentValue': this.gaugepost.tags[i].results[0].values[0][1]
                    };
            this.GaugeInv1.push(obj);
                  }

                  for (let i = 3; i < 6; i++) {
                    const obj1 = {
               'sensorRealName': this.guageArray[i].sensorRealName,
                      'unit': this.guageArray[i].unit,
                      'thresholdMax': this.guageArray[i].thresholdMax,
                      'currentValue': this.gaugepost.tags[i].results[0].values[0][1]
                    };

                    this.GaugeInv2.push(obj1);

                  }
                }

              );


          }
        }

      );



  }


  getData() {
    this.userService.getUser(this.assetId)
      .subscribe(
        returnData => {
          this.tableData = returnData;
          if (this.tableData.length !== 0) {

            console.log('table data', this.tableData);
            this.getData2(this.tableData);
          }
        }
      );
  }


  getData2(tableData1) {
    this.userService.getUser2(this.assetId)
      .subscribe(
        returnData => {
          this.tableData2 = returnData;
          console.log('table data2', this.tableData2);
          this.generateTable(this.tableData2, tableData1);
        }
      );
  }

  generateTable(tableData1, tableData2) {
    const tableArray = [];
    const that = this;
    this.tb1 = tableData1;
    this.tb2 = tableData1;
    tableData1.forEach(function (tableData1) {
      tableData2.forEach(function (tableData2) {

        that.icon1 = false;
        that.icon2 = false;
        if (tableData1.sensorTag === tableData2.sensorName) {


          if (tableData1.alertStatus === 'Y') {

           

            console.log(tableData1.alertStatus);
           that.icon1 = true;
          //  that.icon2 =false;

        
         console.log("Y",that.icon1 = true);
          } else if (tableData1.alertStatus === 'N') {
            
           that.icon2 = true;
          //  that.icon1 =false;
          
          }


          const obj = {
            'sensorName': tableData1.sensorRealName,
            'alertStatus': that.icon1,
            'lastMtrReading': tableData1.lastMtrReading,
            'latestValue': tableData1.latestValue,
            'efficiency': tableData2.effeciency,
            'ratedValue': tableData2.ratedValue,
            'thresholdMin': tableData2.thresholdMin,
            'thresholdMax': tableData2.thresholdMax
          };
          tableArray.push(obj);
        }
      });
    });

    console.log('tableArray', tableArray);
    this.finalTableData = tableArray;
    console.log(this.finalTableData);

    this.finalData1 = [];
    this.finalData2 = [];


 
if(this.assetId != 'Wind-Mill'){
  
   
  for (let i = 0; i < 3; i++) {
    this.finalData1.push(this.finalTableData[i]);
  }


  for (let i = 3; i < 6; i++) {


    this.finalData2.push(this.finalTableData[i]);

  }


  this.final1 = this.finalData1;
  this.final2 = this.finalData2;



}else{
// this.panel1Name='Wind-Mill';
// this.panel2hide=false;
  this.final1=this.finalTableData;
}

    
    // for (let i = 0; i < 3; i++) {
    //   this.finalData1.push(this.finalTableData[i]);
    // }


    // for (let i = 3; i < 6; i++) {


    //   this.finalData2.push(this.finalTableData[i]);

    // }
  
  
    // this.final1 = this.finalData1;
    // this.final2 = this.finalData2;


    console.log('"this.finalData1"', this.finalData1);
    console.log('"this.finalData2"', this.finalData2);
    console.log('"this.finalData"', this.finalTableData);

  

  }




}


export interface User {
  sensorRealName: string;
  alertStatus: string;
  latestValue: string;
  ratedValue: string;
  effeciency: string;
  lastMtrReading: string;
  thresholdMax: string;
  thresholdMin: string;
}
