import { Component, OnInit, AfterViewInit, OnChanges } from '@angular/core';
import { ColumnChartComponent } from '../column-chart/column-chart.component';
import { AppComponent } from './../app.component';
import { Http, Response } from '@angular/http';
import { DashboardServiceService } from '../service/dashboard-service.service';

@Component({
  selector: 'app-management-dashboard',
  templateUrl: './management-dashboard.component.html',
  styleUrls: ['./management-dashboard.component.css']
})
export class ManagementDashboardComponent implements OnInit {

  selected = 'All Assets';
  summaryData: any = [];
  plantInfo: any = [];
  summary: any = [];
  plantData: any = [];
  co2Info: any = [];
  co2Data: any = [];
  Data: any;
  PlantInfoData: any = [];
  CO2Data: any;
  energyCostSaving: any = [];
  comparativePerformance: any = [];
  displayedColumns = ['revenueGenerated', 'maintenanceExpenditure', 'downTime', 'downTimeLoss'];
  displayedColumns1 = ['powerGeneration', 'units', 'commissionedDate'];
  displayedColumns2 = ['co2AvoidedToday', 'todayUnits', 'co2AvoidedTotal', 'totalUnits'];



  comparativeChartData = [];
  comparativeChartCategory = [];
  comparativeChartUnit;
  comparativeGraphTitle;
  comparativeyAxisText;


  revenueChartData = [];
  revenueChartCategory = [];
  revenueChartUnit;
  revenueGraphTitle;
  revenueyAxisText;
  constructor(private myservice: DashboardServiceService, private appComponent: AppComponent) { }
  // ngOnChanges() {
  //   this.appComponent.startLoading();
  // }
  ngOnInit() {
    this.checkForLoading();
    this.callEverything();
  }

  checkForLoading() {
    if (this.appComponent.getLoading() === false) {
      console.log("in check for loading management dashboard");
       const that = this;
      setTimeout(function() {
        that.appComponent.startLoading();
      }, 30);
    }
   }

  callEverything() {
    console.log(this.selected);
    this.getPlantInfoData(this.selected);
    this.getCO2InfoData(this.selected);
    this.getSummaryData(this.selected);
    this.getEnergyCostSaving();
    this.getComparativePerformance();
  }


  assetChanged() {
    if ( this.selected === 'All Assets') {
       this.callEverything();
    } else {
      // this.myservice.getPerformance(this.selected);
      this.getComparativePerformance(this.selected);
      this.getEnergyCostSaving(this.selected);
      this.getPlantInfoData(this.selected);
      this.getCO2InfoData(this.selected);
      this.getSummaryData(this.selected);
    }
  }

  getPlantInfoData(asset) {
    this.myservice.getPlantInformation(asset).subscribe((res) => {
    /*   this.PlantInfoData=[];
      this.plantData=[];  */
      this.plantData.push(res);
      console.log(this.plantData);
      this.PlantInfoData = this.plantData;
    //  this.PlantInfoData = [JSON.parse(res["_body"])];
    });
  }

  getCO2InfoData(asset) {
    this.myservice.getCO2Avoided(asset).subscribe((res) => {
      //  this.CO2Data=[];
      // this.co2Data=[];
      this.co2Data.push(res);
      console.log(this.co2Data);
      this.CO2Data = this.co2Data;
     // this.CO2Data = [JSON.parse(res["_body"])];
    });
  }

  getSummaryData(asset) {
    this.myservice.getSummarydetails(asset).subscribe((res) => {
      //  this. summary=[];
      // this.Data=[];
      this.summary.push(res);
      console.log(this.summary);
      this.Data = this.summary;
      // this.Data = [JSON.parse(res["_body"])];

    });
  }

  getEnergyCostSaving(asset?: string) {

    this.revenueGraphTitle = 'Revenue Chart';
    this.revenueyAxisText = 'INR';
    const revenueValue = (asset === null ? this.myservice.getEnergyCostSaving() :
  this.myservice.getEnergyCostSaving(asset));
  revenueValue.subscribe (
    (data) => {
      console.log("revenue data", data);
      const mainData1 = [];
      const category1 = [];
      this.revenueChartUnit = 'kWh';
      for ( let i = 0; i < Object.keys(data).length; i++) {
        const assetNameFromResponse1 = data[i]['assetName'];
        const innerData1 = [];
        const values = data[i]['data'];
        for ( let j = 0; j < values.length; j++) {
            innerData1.push(values[j]['value']);
            if (i === 1) {
                category1.push(values[j]['month']);
            }
        }
        const eachData1 = {
            'name' : assetNameFromResponse1,
            'data' : innerData1
        };
        mainData1.push(eachData1);
        console.log("main data", mainData1);
    }
    this.revenueChartData = mainData1;
    console.log("response",this.revenueChartData);
    this.revenueChartCategory = category1;
    });
    }

  getComparativePerformance(asset?: string) {
    this.comparativeGraphTitle = 'Performance';
    this.comparativeyAxisText = 'Performance Ratio(%)';
    const energyValue = (asset === null ? this.myservice.getPerformance() :
  this.myservice.getPerformance(asset));
  energyValue.subscribe (
   (data) => {
        console.log("performance data", data);
      const mainData = [];
      const category = [];
      this.comparativeChartUnit = '%';
   for ( let i = 0; i < Object.keys(data).length; i++) {
       const assetNameFromResponse = data[i]['assetName'];
       const innerData = [];
       const values = data[i]['data'];
       for ( let j = 0; j < values.length; j++) {
           innerData.push(values[j]['value']);
           if (i === 1) {
               category.push(values[j]['month']);
           }
       }
       const eachData = {
           'name' : assetNameFromResponse,
           'data' : innerData
       };
       mainData.push(eachData);
       console.log("main data", mainData);
   }
   this.comparativeChartData = mainData;
   console.log("response",this.comparativeChartData);
   this.comparativeChartCategory = category;
   this.appComponent.stopLoading();
   });
}

}
