import { Component, OnInit, Input, OnChanges, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-column-chart',
  templateUrl: './column-chart.component.html',
  styleUrls: ['./column-chart.component.css']
})
export class ColumnChartComponent implements OnInit, OnChanges  {

  @Input()
  dataValues = [];
  @Input()
  categories = [];
  @Input()
  graphTitle ;
  @Input()
  yAxisText;
  @Input()
  unit;
  @Input()
  wdt;
  @Input()
  hgt;
  values;
  chart: any;
  options: any;
  ngOnInit() {
    this.ifNoData();
    this.constructGraph();
  }

  ngOnChanges() {
    this.ifNoData();
    this.constructGraph();
  }

  ifNoData() {
    if (this.dataValues.length === 0 && this.unit === '%') {
         this.dataValues = [{'name': this.graphTitle, 'data': [0, 0, 0 , 0, 0, 0, 0 , 0, 0, 0, 0 , 0]}];
         this.categories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
         // this.performanceGraphTitle = 'Performance';
         this.yAxisText = 'Performance Ratio(%)';
    } else if ( this.dataValues.length === 0 && this.unit === 'kWh') {
        this.dataValues = [{'name': this.graphTitle, 'data':  [0, 0, 0 , 0, 0, 0, 0 , 0, 0, 0, 0 , 0]}];
        this.categories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        // this.performanceGraphTitle = 'Performance';
        this.yAxisText = 'Energy(kWh)';

    }
  }

  constructGraph() {

    this.options = {
      chart: {
        type: 'column',
      
      height: this.hgt,
      width : this.wdt 
    },
    title: {
        text: this.graphTitle
    },
    xAxis: {
        categories: this.categories,
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
             text: this.yAxisText
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f}' + this.unit + '</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: this.dataValues
};

  }

  constructor() {
    }

  saveInstance(chartInstance) {
    this.chart = chartInstance;
  }

}
