import { Component, OnInit, ViewChild, OnChanges, Input } from '@angular/core';
import { MatPaginator, MatTableDataSource } from '@angular/material';
import { MyServiceService } from 'src/app/service/my-service.service';
import { DataSource } from '@angular/cdk/collections';
import { NgxSpinnerService } from 'ngx-spinner';
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';


@Component({
  selector: 'app-incident',
  templateUrl: './incident.component.html',
  styleUrls: ['./incident.component.css']
})
export class IncidentComponent implements OnInit {

  value: any;

  isAlert = false;

  alertmessage: any;
  assetId: any;
  chartDataValues;
  keyArray: string[];
  ticketData: any;
  chartData: any;
  alertData;
  ChartDataFin=[];
  displayedColumns = ['incidentId', 'sensorName', 'sensorData', 'initiatedTime'];

  dataSource = new MatTableDataSource<PeriodicElement>();


  display = false;



  @ViewChild(MatPaginator) paginator: MatPaginator;


  constructor(private userService: MyServiceService, private spinner: NgxSpinnerService) {

  //   this.userService.listen().subscribe((m:any) => {
  //     console.log(m);
  //     this.onFilterClick(m);
  // });

  this.userService.currentJobName.subscribe((message: any) => {

    this.onFilterClick(message);

  });

  // this.userService.currentJobNameEver.subscribe((message:any)=>{
  //   this.onFilterClick1(message)
  // })
  }

  ngOnInit() {

    this.dataSource.paginator = this.paginator;

  }
  onFilterClick(event) {
    console.log('"inside inicent component"', event);
    this.assetId = event;

   this.getTicketData();
   this.getAlertMsgData();
   this.getChartData();
    console.log('"event asset id"', this.assetId);
  }


  // onFilterClick(event){

  //   console.log("inside inicent component",event.value)
  //   this.assetId = event.value;

  //  this.getTicketData();
  //  this.getAlertMsgData();
  //  this.getChartData();
  //   console.log("event asset id",this.assetId)
  // }


  getAlertMsgData() {

    this.userService.getAlertMsg(this.assetId)
      .subscribe(
        returnData => {
          this.alertData = returnData;

          console.log('"alertmsgdata"', this.alertData);
          if (this.alertData.length !== 0) {
          if (this.alertData.caseString === 'Y') {
            this.display = true;
            this.isAlert = true;
            console.log(this.alertData.caseString);
this.alertmessage = this.alertData.message;
          }
        }
      }
      );
  }

  getTicketData() {

    this.ticketData = [];
    this.userService.getticket(this.assetId)
      .subscribe(
        returnData => {
          this.ticketData = returnData;
          console.log('"this.ticketData"', this.ticketData);
          if (this.ticketData.length !== 0) {
          this.sample(this.ticketData);


        }

      }
      );



  }


  sample(body) {
    console.log('"sample"');
    this.dataSource = new MatTableDataSource<PeriodicElement>(body);
    this.dataSource.paginator = this.paginator;

    this.spinner.hide();
  }



  getChartData() {

    this.userService.getChart(this.assetId)
      .subscribe(
        returnData => {
          this.chartDataValues = returnData;

          if (this.chartDataValues.length !== 0) {
          this.constructData(this.chartDataValues);


          }

        }
      );


  }


  constructData(graphData) {


    this.keyArray = Object.keys(graphData[0]);
    const chartData = [];
    for (let i = 0; i < this.keyArray.length; i++) {
      if (this.keyArray[i] !== 'Date') {
        const chartData1 = [];
        const name = this.keyArray[i];
        for (let j = 0; j < this.chartDataValues.length; j++) {
          const data = [];
          const date = this.chartDataValues[j].Date;
          for (const key in graphData[j]) {
            if (name === key) {
              this.value = graphData[j][key];
            }
          }
          data.push(date);
          data.push(this.value);
          chartData1.push(data);
          chartData1.sort();
        }
        const chart = {
          name: name,
          data: chartData1
        };
        chartData.push(chart);
      }
    }
    this.ChartDataFin = chartData;

    // Highcharts.chart('container', {
    //   chart: {
    //     type: 'line'
    // },
    //   title: {
    //     text: 'Anomaly Count'
    //   },

    //   xAxis: {
    //     type: 'datetime',
    //     dateTimeLabelFormats: {
    //       month: '%e. %b',
    //       year: '%b'
    //     },
    //     title: {
    //       text: 'Date'
    //     }
    //   },

    //   yAxis: {
    //     title: {
    //       text: 'Threshold Breach Count'
    //     },
    //     min: 0
    //   },
    //   credits: {
    //     enabled: false
    //   },
    //   tooltip: {
    //     headerFormat: '<b>{series["name"]}</b><br>',
    //     pointFormat: '{point.x:%e. %b}: {point.y:.2f}'
    //   },

    //   plotOptions: {
    //     spline: {
    //       marker: {
    //         enabled: true
    //       }
    //     }
    //   },



    //   series: chartData

    // });

  }



}

export interface PeriodicElement {
  incidentId: number;
  sensorName: string;
  sensorData: number;
  initiatedTime: string;
}


