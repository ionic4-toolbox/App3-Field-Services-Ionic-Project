import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weather-monitoring',
  templateUrl: './weather-monitoring.component.html',
  styleUrls: ['./weather-monitoring.component.css']
})
export class WeatherMonitoringComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
