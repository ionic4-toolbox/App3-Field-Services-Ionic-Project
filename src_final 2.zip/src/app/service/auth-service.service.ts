import { Injectable } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { Router } from '@angular/router';
import { map, filter, catchError, mergeMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  url = '../../assets/jsons/auth.json';
  loggedIn = false ;
  constructor(private appService: AppServiceService , private router: Router) { }

  logInValidation(credentials) {
    return  this.appService.doGet(this.url).pipe(
      map((data: any[]) => {
        console.log('json data', data);
        this.loggedIn = data['valid'];
        return data['valid'];
      })
   );
  }

  isLoggedIn() {
      return this.loggedIn;
  }
  logOut() {
    this.loggedIn = false;
  }
}
