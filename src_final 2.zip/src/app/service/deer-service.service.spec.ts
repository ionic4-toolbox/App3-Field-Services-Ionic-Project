import { TestBed, inject } from '@angular/core/testing';

import { DeerServiceService } from './deer-service.service';

describe('DeerServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DeerServiceService]
    });
  });

  it('should be created', inject([DeerServiceService], (service: DeerServiceService) => {
    expect(service).toBeTruthy();
  }));
});
