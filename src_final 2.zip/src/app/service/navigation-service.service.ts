import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NavigationServiceService {

 private  _selectedNav: string;
  constructor() {
    this._selectedNav='dash';
   }
   get selectedNav(): string{
    return this._selectedNav;
   }
   set selectedNav(tab:string){
     this._selectedNav = tab;
   }
}
