// import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DashboardServiceService {

  // cumilative
  tokenUrl = 'https://fcb7ec9a-3d36-4fb6-9ed2-7c5e7d671f11.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token';
  smartCityUrl = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/smartcityassets';
  smartCityAssetChild = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/smartcityassetschild';
  solarAssetLocation = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/solarAssetLocation';
  solarAssetBuilding = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/solarAssetBuilding';
  currentPowerURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getCurrentPower';
  soFarTodayURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getCurrentEnergy';
  monthAvgEtodURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getMonthAvgEtod';
  contributionURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getContribution';
  alertDataURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAlerts';
  energyValuesMonthly = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getMonthlyEnergy';
  performanceURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getMonthlyPerformanceRatio';
  // asset wise
  alertDataURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetAlerts?assetName=';
  alertMsg = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/alertMessagePop?assetName=';
  currentPowerURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetCurrentPower';
  monthAvgEtodURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetMonthAvgEtod';
  soFarTodayURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetCurrentEnergy';
  contributionURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetContribution';
  energyValuesURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetMonthlyEnergy';
  performanceURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetMonthlyPerformanceRatio';




  revenueChartURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getRevenueChart';
  revenueChartURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetRevenueChart';
  constructor(  private appService: AppServiceService) { }

  commonUrl = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io';


getToken() {
    const tokenBody = 'app_client_id=hack_client&grant_type=client_credentials';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'authorization': 'Basic aGFja19jbGllbnQ6aGFja19jbGllbnQ='
      })
    };
   return this.appService.doPost(this.tokenUrl, tokenBody, httpOptions);

}

getSmartCityAssets(assetHeaders) {
  return this.appService.doGet(this.smartCityUrl, assetHeaders);
}

getSmartcityAssetschild(assetHeaders) {
 return this.appService.doGet(this.smartCityAssetChild, assetHeaders);
}

getSolarAssetLocation(assetHeaders) {
  return this.appService.doGet(this.solarAssetLocation, assetHeaders);
}

getSolarAssetBuilding(assetHeaders) {
  return this.appService.doGet(this.solarAssetBuilding, assetHeaders);
}
getAlertStatus(assetName) {
  return this.appService.doGet(this.alertMsg + assetName);
}
getCurrentStatus(assetName?: string) {
  if (assetName == null) {
  return this.appService.doGet(this.currentPowerURL);
 } else {
  return this.appService.doGet(this.currentPowerURLAsset + '?assetName' + '=' + assetName);
 }
}
getSoFarToday(assetName?: string) {
  if (assetName == null) {
  return this.appService.doGet(this.soFarTodayURL);
 } else {
  return this.appService.doGet(this.soFarTodayURLAsset + '?assetName' + '=' + assetName);
 }
}

getMonthAvg(assetName?: string) {
  if (assetName == null) {
  return this.appService.doGet(this.monthAvgEtodURL);
 } else {
  return this.appService.doGet(this.monthAvgEtodURLAsset + '?assetName' + '=' + assetName);
 }
}

getContribution(assetName?: string) {
  if (assetName == null) {
    return this.appService.doGet(this.contributionURL);
   } else {
    return this.appService.doGet(this.contributionURLAsset + '?assetName' + '=' + assetName);
   }
}

getAlertData(assetName?: string) {
  if (assetName == null) {
    return this.appService.doGet(this.alertDataURL);
   } else {
    return this.appService.doGet(this.alertDataURLAsset + '?assetName' + '=' + assetName);
   }
}

getEnergyValue(assetName?: string) {
  if (assetName == null) {
    return this.appService.doGet(this.energyValuesMonthly);
   } else {
    return this.appService.doGet(this.energyValuesURLAsset + '?assetName' + '=' + assetName);
   }
}




getPlantInformation(assetName) {
  let url;
  (assetName === 'All Assets') ? (url = `${this.commonUrl}/getCurrentPower`) : (url =
    `${this.commonUrl}/getAssetCurrentPower?assetName=${assetName}`);
  return this.appService.doGet(url);
}

getCO2Avoided(assetName) {
  let url;
  (assetName === 'All Assets') ? (url = `${this.commonUrl}/getCo2`) : (url =
    `${this.commonUrl}/getAssetCo2?assetName=${assetName}`);
  return this.appService.doGet(url);
}


getSummarydetails(assetName) {
  let url;
  (assetName === 'All Assets') ? (url = `${this.commonUrl}/getRevenue`) : (url =
    `${this.commonUrl}/getAssetRevenue?assetName=${assetName}`);
  return this.appService.doGet(url);
}


getEnergyCostSaving(assetName?: string) {
  console.log("in assetName",assetName);
  if (assetName === undefined) {
    return this.appService.doGet('https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getRevenueChart');
  } else {
    return this.appService.doGet(this.revenueChartURLAsset + '?assetName' + '=' + assetName);
   }

}

getPerformance(assetName?: string) {
  if (assetName == null) {
    return this.appService.doGet(this.performanceURL);
   } else {
    return this.appService.doGet(this.performanceURLAsset + '?assetName' + '=' + assetName);
   }
}


}
