import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoaderServiceService {

  public loading;
  constructor() {
    this.loading = true;
   }

stopLoading() {
  this.loading = false;
}

startLoading() {
  this.loading = true;
}

getLoading() {
  return this.loading;
}

}
