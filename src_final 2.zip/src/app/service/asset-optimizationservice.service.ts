import { Injectable } from '@angular/core';
import { AppServiceService } from './../app-service.service';
import { HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AssetOptimizationserviceService {

  performanceURL="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getMonthlyPerformanceRatio";
  efficiencyChartURL="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/fetchEfficiencyTable";
  energyValuesURL="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/fetchEnergyGeneratedTable";
  performanceURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetMonthlyPerformanceRatio';
  
  tiltAngle="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getBetaValues";

  constructor(private appService: AppServiceService) { }

  getPerformanceForOptimization(assetName?: string){
    if (assetName == null) {
      return this.appService.doGet(this.performanceURL);
     } else {
      return this.appService.doGet(this.performanceURLAsset + '?assetName' + '=' + assetName);
     }
  }
  
  getOverAllEffForOptimization(assetName?: string){
    if (assetName == null) {
      return this.appService.doGet(this.efficiencyChartURL);
     } else {
      return this.appService.doGet(this.efficiencyChartURL + '?assetName' + '=' + assetName);
     }
  }
  
  getEnergyForOptimization(assetName?: string){
    if (assetName == null) {
      return this.appService.doGet(this.energyValuesURL);
     } else {
      return this.appService.doGet(this.energyValuesURL + '?assetName' + '=' + assetName);
     }
  }

  getTiltAngleInfo(tiltAngle?: string){
    if (tiltAngle == null) {
      return this.appService.doGet(this.tiltAngle);
     } else {
      return this.appService.doGet(this.tiltAngle + '?latitude' + '=' + tiltAngle);
     }
  }
}
