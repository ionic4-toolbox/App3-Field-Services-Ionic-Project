import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders} from '@angular/common/http';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { Observable } from "rxjs";
import { Subject } from 'rxjs';

import { BehaviorSubject } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {


  // private _listners = new Subject<any>();

  //   listen(): Observable<any> {
  //      return this._listners.asObservable();
  //   }

  //   filter(filterBy: string) {
  //      this._listners.next(filterBy);
  //   }






    private jobNames = new BehaviorSubject<any>('');
   
    currentJobName = this.jobNames.asObservable(); 
    

    setJobName(name: any) {
      this.jobNames.next(name);
    } 


    //lattitude
      private tiltAngle = new BehaviorSubject<any>('');
   
  currentTiltAngleInfo = this.tiltAngle.asObservable(); 

    setTiltAngle(name: any){
      this.tiltAngle.next(name);
    }


    //long
    private long = new BehaviorSubject<any>('');
   
    currentlongInfo = this.long.asObservable(); 
  
      setlong(name: any){
        this.long.next(name);
      }

      


  
// assetId=localStorage.getItem("assetId");
// assetId="SEZ-Building3";
opts


  constructor(public http: HttpClient) { 

 

  }

     headers: HttpHeaders = new HttpHeaders({

      'Predix-Zone-Id':'69cf0edb-2ba7-40fe-84e3-614a61fe46f0',
      'authorization':'bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2ODZjZWQyODY2ZDg0MjUwOGNkZjAwZmM4YTgyM2JkOCIsInN1YiI6ImhhY2tfY2xpZW50Iiwic2NvcGUiOlsidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LnF1ZXJ5IiwicGItZ2VvLnpvbmVzLjg4YzhkZmNmLWZhNDgtNDZmYy1hMjUzLTU4ODdmNTgxZjEwNS51c2VyIiwiYXp1cXVhLnpvbmVzLjc0YzNmOThmLTFkZTktNDA5OS05NWIzLTAyZDExNDcxMDQ0My51c2VyIiwidWFhLmFkbWluIiwicHJlZGl4LWFzc2V0LnpvbmVzLjY5Y2YwZWRiLTJiYTctNDBmZS04NGUzLTYxNGE2MWZlNDZmMC51c2VyIiwidGltZXNlcmllcy56b25lcy5hNDIxYTE4MS1kZmIzLTRhYzUtODdhNS0xYjUzYjE2OGNjYmMudXNlciIsInRpbWVzZXJpZXMuem9uZXMuYTQyMWExODEtZGZiMy00YWM1LTg3YTUtMWI1M2IxNjhjY2JjLnF1ZXJ5IiwiYW5hbHl0aWNzLnpvbmVzLjcyYjhlNWFjLWJmNzUtNGFkYi1iNTY0LTQxZTVhZGVlNTJjNC51c2VyIiwibm90aWZpY2F0aW9uLnpvbmUuYWVmN2M1OWEtOTBmNS00MWQ4LWE3YmItNTc5OGY5MGIwYzg5LnVzZXIiLCJ0aW1lc2VyaWVzLnpvbmVzLjY2ODFkZTk5LTVlNjctNDNlYy1iMGYzLWZjODNlN2RmZTM5NC5pbmdlc3QiLCJhbmFseXRpY3Muem9uZXMuOTQ4OWVjMGItZTc5ZC00MzM3LWFkOWEtN2JhOTY1OGE0YWFlLnVzZXIiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy5mOTA0OGRmYS1lMTVkLTRiZmUtOTNkNy1mZTU4OTJlNzllOWYudXNlciIsInBpdG5leS1ib3dlcy1nZW9lbmhhbmNlbWVudC1zZXJ2aWNlLnpvbmVzLjg4YzhkZmNmLWZhNDgtNDZmYy1hMjUzLTU4ODdmNTgxZjEwNS51c2VyIiwidGltZXNlcmllcy56b25lcy5hNDIxYTE4MS1kZmIzLTRhYzUtODdhNS0xYjUzYjE2OGNjYmMuaW5nZXN0IiwiYW5hbHl0aWNzLnpvbmVzLjY2OTY2YjA0LTQ5OWEtNGMwMy1iMzhmLTdiMjIxODUxYzA1NS51c2VyIiwiYW5hbHl0aWNzLnpvbmVzLjFiMGNhZDNiLTI4MGUtNDg3NC1iNTE2LTVjODMxZDU1N2Q5My51c2VyIl0sImNsaWVudF9pZCI6ImhhY2tfY2xpZW50IiwiY2lkIjoiaGFja19jbGllbnQiLCJhenAiOiJoYWNrX2NsaWVudCIsImdyYW50X3R5cGUiOiJjbGllbnRfY3JlZGVudGlhbHMiLCJyZXZfc2lnIjoiZGM3Njc0NCIsImlhdCI6MTUyOTMxNjMyMCwiZXhwIjoxNTYwODUyMzE5LCJpc3MiOiJodHRwczovL2ZjYjdlYzlhLTNkMzYtNGZiNi05ZWQyLTdjNWU3ZDY3MWYxMS5wcmVkaXgtdWFhLnJ1bi5hd3MtdXN3MDItcHIuaWNlLnByZWRpeC5pby9vYXV0aC90b2tlbiIsInppZCI6ImZjYjdlYzlhLTNkMzYtNGZiNi05ZWQyLTdjNWU3ZDY3MWYxMSIsImF1ZCI6WyJub3RpZmljYXRpb24uem9uZS5hZWY3YzU5YS05MGY1LTQxZDgtYTdiYi01Nzk4ZjkwYjBjODkiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzIiwiYW5hbHl0aWNzLnpvbmVzLjk0ODllYzBiLWU3OWQtNDMzNy1hZDlhLTdiYTk2NThhNGFhZSIsImFuYWx5dGljcy56b25lcy5mOTA0OGRmYS1lMTVkLTRiZmUtOTNkNy1mZTU4OTJlNzllOWYiLCJ0aW1lc2VyaWVzLnpvbmVzLmE0MjFhMTgxLWRmYjMtNGFjNS04N2E1LTFiNTNiMTY4Y2NiYyIsInVhYSIsImFuYWx5dGljcy56b25lcy42Njk2NmIwNC00OTlhLTRjMDMtYjM4Zi03YjIyMTg1MWMwNTUiLCJwaXRuZXktYm93ZXMtZ2VvZW5oYW5jZW1lbnQtc2VydmljZS56b25lcy44OGM4ZGZjZi1mYTQ4LTQ2ZmMtYTI1My01ODg3ZjU4MWYxMDUiLCJ0aW1lc2VyaWVzLnpvbmVzLjY2ODFkZTk5LTVlNjctNDNlYy1iMGYzLWZjODNlN2RmZTM5NCIsInBiLWdlby56b25lcy44OGM4ZGZjZi1mYTQ4LTQ2ZmMtYTI1My01ODg3ZjU4MWYxMDUiLCJhbmFseXRpY3Muem9uZXMuNzJiOGU1YWMtYmY3NS00YWRiLWI1NjQtNDFlNWFkZWU1MmM0IiwiaGFja19jbGllbnQiLCJhbmFseXRpY3Muem9uZXMuMWIwY2FkM2ItMjgwZS00ODc0LWI1MTYtNWM4MzFkNTU3ZDkzIiwicHJlZGl4LWFzc2V0LnpvbmVzLjY5Y2YwZWRiLTJiYTctNDBmZS04NGUzLTYxNGE2MWZlNDZmMCJdfQ.Uvc5TdHo-87shdBEbl1nNXlvXiYiSdLnmzCQNG54iqLTSosFsd8LoMB3di1bxi4lF4pJ1PtIMXBIZwVqvMeJVcjzAYB-L86PGLr15E-hXd35xHj0ndFGuApltBwqZ6CmtXM5Q2l4wYzLivB2w7dvy7QvdrVwlzMMN2q268vI8c7dYC2-47OQVl_IUnr3Ul1gUr4JNCrpWC2eRhmQ9o4sHTMWKKks7dUE3t_R7nV9X8NphRqy_RztLqjw_F9uLkzp9Qzo_4ybFvHmwE8F3Akthx0H0X2alRsdLjLs-FLmukwTBT6g9fijvYdYHZ8QoChPj3rXmOjTaVbVZ8qIpemdQg',
      'Content-Type':'application/json'
    });


    headers2: HttpHeaders = new HttpHeaders({

      'Predix-Zone-Id':'6681de99-5e67-43ec-b0f3-fc83e7dfe394',
      'authorization':'bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2ODZjZWQyODY2ZDg0MjUwOGNkZjAwZmM4YTgyM2JkOCIsInN1YiI6ImhhY2tfY2xpZW50Iiwic2NvcGUiOlsidGltZXNlcmllcy56b25lcy42NjgxZGU5OS01ZTY3LTQzZWMtYjBmMy1mYzgzZTdkZmUzOTQudXNlciIsInRpbWVzZXJpZXMuem9uZXMuNjY4MWRlOTktNWU2Ny00M2VjLWIwZjMtZmM4M2U3ZGZlMzk0LnF1ZXJ5IiwicGItZ2VvLnpvbmVzLjg4YzhkZmNmLWZhNDgtNDZmYy1hMjUzLTU4ODdmNTgxZjEwNS51c2VyIiwiYXp1cXVhLnpvbmVzLjc0YzNmOThmLTFkZTktNDA5OS05NWIzLTAyZDExNDcxMDQ0My51c2VyIiwidWFhLmFkbWluIiwicHJlZGl4LWFzc2V0LnpvbmVzLjY5Y2YwZWRiLTJiYTctNDBmZS04NGUzLTYxNGE2MWZlNDZmMC51c2VyIiwidGltZXNlcmllcy56b25lcy5hNDIxYTE4MS1kZmIzLTRhYzUtODdhNS0xYjUzYjE2OGNjYmMudXNlciIsInRpbWVzZXJpZXMuem9uZXMuYTQyMWExODEtZGZiMy00YWM1LTg3YTUtMWI1M2IxNjhjY2JjLnF1ZXJ5IiwiYW5hbHl0aWNzLnpvbmVzLjcyYjhlNWFjLWJmNzUtNGFkYi1iNTY0LTQxZTVhZGVlNTJjNC51c2VyIiwibm90aWZpY2F0aW9uLnpvbmUuYWVmN2M1OWEtOTBmNS00MWQ4LWE3YmItNTc5OGY5MGIwYzg5LnVzZXIiLCJ0aW1lc2VyaWVzLnpvbmVzLjY2ODFkZTk5LTVlNjctNDNlYy1iMGYzLWZjODNlN2RmZTM5NC5pbmdlc3QiLCJhbmFseXRpY3Muem9uZXMuOTQ4OWVjMGItZTc5ZC00MzM3LWFkOWEtN2JhOTY1OGE0YWFlLnVzZXIiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy5mOTA0OGRmYS1lMTVkLTRiZmUtOTNkNy1mZTU4OTJlNzllOWYudXNlciIsInBpdG5leS1ib3dlcy1nZW9lbmhhbmNlbWVudC1zZXJ2aWNlLnpvbmVzLjg4YzhkZmNmLWZhNDgtNDZmYy1hMjUzLTU4ODdmNTgxZjEwNS51c2VyIiwidGltZXNlcmllcy56b25lcy5hNDIxYTE4MS1kZmIzLTRhYzUtODdhNS0xYjUzYjE2OGNjYmMuaW5nZXN0IiwiYW5hbHl0aWNzLnpvbmVzLjY2OTY2YjA0LTQ5OWEtNGMwMy1iMzhmLTdiMjIxODUxYzA1NS51c2VyIiwiYW5hbHl0aWNzLnpvbmVzLjFiMGNhZDNiLTI4MGUtNDg3NC1iNTE2LTVjODMxZDU1N2Q5My51c2VyIl0sImNsaWVudF9pZCI6ImhhY2tfY2xpZW50IiwiY2lkIjoiaGFja19jbGllbnQiLCJhenAiOiJoYWNrX2NsaWVudCIsImdyYW50X3R5cGUiOiJjbGllbnRfY3JlZGVudGlhbHMiLCJyZXZfc2lnIjoiZGM3Njc0NCIsImlhdCI6MTUyOTMxNjMyMCwiZXhwIjoxNTYwODUyMzE5LCJpc3MiOiJodHRwczovL2ZjYjdlYzlhLTNkMzYtNGZiNi05ZWQyLTdjNWU3ZDY3MWYxMS5wcmVkaXgtdWFhLnJ1bi5hd3MtdXN3MDItcHIuaWNlLnByZWRpeC5pby9vYXV0aC90b2tlbiIsInppZCI6ImZjYjdlYzlhLTNkMzYtNGZiNi05ZWQyLTdjNWU3ZDY3MWYxMSIsImF1ZCI6WyJub3RpZmljYXRpb24uem9uZS5hZWY3YzU5YS05MGY1LTQxZDgtYTdiYi01Nzk4ZjkwYjBjODkiLCJhenVxdWEuem9uZXMuNzRjM2Y5OGYtMWRlOS00MDk5LTk1YjMtMDJkMTE0NzEwNDQzIiwiYW5hbHl0aWNzLnpvbmVzLjk0ODllYzBiLWU3OWQtNDMzNy1hZDlhLTdiYTk2NThhNGFhZSIsImFuYWx5dGljcy56b25lcy5mOTA0OGRmYS1lMTVkLTRiZmUtOTNkNy1mZTU4OTJlNzllOWYiLCJ0aW1lc2VyaWVzLnpvbmVzLmE0MjFhMTgxLWRmYjMtNGFjNS04N2E1LTFiNTNiMTY4Y2NiYyIsInVhYSIsImFuYWx5dGljcy56b25lcy42Njk2NmIwNC00OTlhLTRjMDMtYjM4Zi03YjIyMTg1MWMwNTUiLCJwaXRuZXktYm93ZXMtZ2VvZW5oYW5jZW1lbnQtc2VydmljZS56b25lcy44OGM4ZGZjZi1mYTQ4LTQ2ZmMtYTI1My01ODg3ZjU4MWYxMDUiLCJ0aW1lc2VyaWVzLnpvbmVzLjY2ODFkZTk5LTVlNjctNDNlYy1iMGYzLWZjODNlN2RmZTM5NCIsInBiLWdlby56b25lcy44OGM4ZGZjZi1mYTQ4LTQ2ZmMtYTI1My01ODg3ZjU4MWYxMDUiLCJhbmFseXRpY3Muem9uZXMuNzJiOGU1YWMtYmY3NS00YWRiLWI1NjQtNDFlNWFkZWU1MmM0IiwiaGFja19jbGllbnQiLCJhbmFseXRpY3Muem9uZXMuMWIwY2FkM2ItMjgwZS00ODc0LWI1MTYtNWM4MzFkNTU3ZDkzIiwicHJlZGl4LWFzc2V0LnpvbmVzLjY5Y2YwZWRiLTJiYTctNDBmZS04NGUzLTYxNGE2MWZlNDZmMCJdfQ.Uvc5TdHo-87shdBEbl1nNXlvXiYiSdLnmzCQNG54iqLTSosFsd8LoMB3di1bxi4lF4pJ1PtIMXBIZwVqvMeJVcjzAYB-L86PGLr15E-hXd35xHj0ndFGuApltBwqZ6CmtXM5Q2l4wYzLivB2w7dvy7QvdrVwlzMMN2q268vI8c7dYC2-47OQVl_IUnr3Ul1gUr4JNCrpWC2eRhmQ9o4sHTMWKKks7dUE3t_R7nV9X8NphRqy_RztLqjw_F9uLkzp9Qzo_4ybFvHmwE8F3Akthx0H0X2alRsdLjLs-FLmukwTBT6g9fijvYdYHZ8QoChPj3rXmOjTaVbVZ8qIpemdQg',
      'Content-Type':'application/json'
    });
   
   

  
  // this.opts = new RequestOptions();
    // this.opts.headers = headers;

  private serviceUrl = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getThresholdValues?assetName=SEZ-Building3';    /*url*/

  private serviceUrl2 = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/assetMonitor?assetName=SEZ-Building3';    /*url*/

  private serviceUrl3="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/energyAttributes?assetName=SEZ-Building3"; /*url gor todays energy*/
  
  private serviceUrl4="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/assetMonitor?assetName=SEZ-Building2"

private serviceUrl5="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAlerts"

private serviceUrl6="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/fetchIncidentTable?assetName=SEZ-Building3"
  
private serviceUrl7="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getDailyIncident?assetName=SEZ-Building3"

private serviceUrl8="https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/alertMessagePop?assetName=SEZ-Building3"

private serviceurl9="https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints/latest" ;         
//  url for gaugr post

 
private serviceUrlDropdown1="https://predix-asset.run.aws-usw02-pr.ice.predix.io/smartcityassets";
private serviceUrlDropdown2="https://predix-asset.run.aws-usw02-pr.ice.predix.io/smartcityassetschild";
private serviceUrlDropdown3="https://predix-asset.run.aws-usw02-pr.ice.predix.io/solarAssetLocation";
private serviceUrlDropdown4="https://predix-asset.run.aws-usw02-pr.ice.predix.io/solarAssetBuilding";

  // getEnergy(assetId) {
  //   let serviceUrl = `https://dev-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/energyAttributes?assetName=${assetId}`;
  //   return this.http.get(serviceUrl);
  //   }

    
  getUser(assetId) { 
    return this.http.get('https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getThresholdValues?assetName='+assetId);
  }

  getUser2(assetId) {
    return this.http.get('https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/assetMonitor?assetName='+assetId);
  }

  getEnergy(assetId){
    return this.http.get("https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/energyAttributes?assetName="+assetId);
  }

  getGauge(assetId){
    return this.http.get("https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/assetMonitor?assetName="+assetId );

   
  }

  getAlert(){
    return this.http.get(this.serviceUrl5);
  }


  getticket(assetId){
    return this.http.get("https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/fetchIncidentTable?assetName="+assetId);
  }

  getChart(assetId){
    return this.http.get("https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getDailyIncident?assetName="+assetId);
  }

  postGauge(body){
    return this.http.post("https://time-series-store-predix.run.aws-usw02-pr.ice.predix.io/v1/datapoints/latest",body,{headers:this.headers2})
    
   
  }

  getAlertMsg(assetId){


    return this.http.get("https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/alertMessagePop?assetName="+assetId)
  }
  //dropdown

  getDrpdown1(){
    return this.http.get(this.serviceUrlDropdown1, {headers: this.headers});
  }

  getDrpdown2(){
    return this.http.get(this.serviceUrlDropdown2, {headers: this.headers});
  }

  getDrpdown3(){
    return this.http.get(this.serviceUrlDropdown3, {headers: this.headers});
  }

  getDrpdown4(){
    return this.http.get(this.serviceUrlDropdown4,{headers: this.headers});
  }



  doPost(url: string , body: any , httpOptions: Object) {
    return this.http.post(url, body, httpOptions);
}
  doGet(url: string, httpOptions?: Object) {
    return (httpOptions !== null ) ? (this.http.get(url, httpOptions)) : (this.http.get(url)) ;
  }

}
