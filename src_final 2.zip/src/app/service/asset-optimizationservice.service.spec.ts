import { TestBed, inject } from '@angular/core/testing';

import { AssetOptimizationserviceService } from './asset-optimizationservice.service';

describe('AssetOptimizationserviceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AssetOptimizationserviceService]
    });
  });

  it('should be created', inject([AssetOptimizationserviceService], (service: AssetOptimizationserviceService) => {
    expect(service).toBeTruthy();
  }));
});
