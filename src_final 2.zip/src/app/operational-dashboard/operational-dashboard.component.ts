import { AppComponent } from './../app.component';
import { Component, OnInit, OnChanges, AfterContentChecked } from '@angular/core';
import { DashboardServiceService } from '../service/dashboard-service.service';
import { HttpHeaders } from '@angular/common/http';
import { LoaderServiceService } from '../service/loader-service.service';

@Component({
  selector: 'app-operational-dashboard',
  templateUrl: './operational-dashboard.component.html',
  styleUrls: ['./operational-dashboard.component.css']
})
export class OperationalDashboardComponent implements OnInit {

  lat =  19.175444 ;
  lng = 72.990211;
  zoom = 15;
  assetHeaders = {} ;
  assets = [];
  markers = [];
  selectedAsset = 'Showing Cumulative Data For All Assets';
  backUpMarkers: any;
  show = false; // default show the refresh button
  powerConsumption = 0;
  powerGeneration = 0;
  powerUnit = 'kW';
  generationTodayValue = 0;
  consumptionTodayValue = 0;
  avgGenerationValue = 0;
  generationUnit = 'kWh';
  avgConsumptionValue = 0;
  consumptionUnit = 'MWh';
  yesterDaySolarContribution = 0;
  last30DaysSolarContribution = 0;
  alertAssetObjects;
  public loading = false;


  energyChartData = [];
  energyCategory = [];
  graphTitle = '';
  yAxisText;
  chartUnit;

  performanceChartData = [];
  performanceCategory = [];
  performancechartUnit;
  performanceGraphTitle;
  performanceyAxisText;

  constructor(private dashboardService: DashboardServiceService,
     private appComponent: AppComponent, private loadingService: LoaderServiceService) { }

  // ngOnChanges() {
  //   this.appComponent.startLoading();
  // }

  // ngAfterContentChecked() {
  //   this.appComponent.startLoading();
  // }
  ngOnInit() {
   // this.setinitialData();
    this.startGettingData();
  }

  startGettingData() {
    this.checkForLoading(); // for showing loader
    this.getToken();
    this.getCurrent();
    this.getSoFarToday();
    this.getAverage();
    this.getSolarContribution();
    this.getAlertData();
    this.getEnergyValue();
    this.getPerformance();
  }

  checkForLoading() {
   if (this.appComponent.getLoading() === false) {
    console.log("in check for loading management dashboard");
    // this.appComponent.startLoading();
     const that = this;
    setTimeout(function() {
      that.appComponent.startLoading();
    }, 30);
  }
   }
  getToken() {
    this.dashboardService.getToken().subscribe(
      // setting the header from token object
     (data) => {
       const token = 'bearer ' + data['access_token'];
       this.assetHeaders = {
         headers: new HttpHeaders({
           'Predix-Zone-Id': '69cf0edb-2ba7-40fe-84e3-614a61fe46f0',
           'authorization': token,
           'Content-Type': 'application/json'
         })
       };
        this.getAssetData();
     }
   );
  }
  getAssetData() {
    this.dashboardService.getSmartCityAssets(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.getAssetChildData();
      }
    );
  }

  getAssetChildData() {
    this.dashboardService.getSmartcityAssetschild(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.getAssetLocationData();
      }
    );
  }
  getAssetLocationData() {
    this.dashboardService.getSolarAssetLocation(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.getAssetBuildingData();
      }
    );
  }
  getAssetBuildingData() {
    this.dashboardService.getSolarAssetBuilding(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.constructMarkers();
      }
    );
  }

  // setting the markers
  constructMarkers() {
    this.assets.forEach(element => {
      element.forEach(eachObject => {
        if (eachObject.hasOwnProperty('lat') && eachObject.hasOwnProperty('lng')) {
          let markerType;

         this.dashboardService.getAlertStatus(eachObject['name']).subscribe(
          (data) => {
            if (data['caseString'] === 'N') {
              markerType = {
                url: './../../assets/green_marker.png',
                scaledSize: {
                  width: 20,
                  height: 30
                }
             };
            } else {
              markerType = {
                url: './../../assets/red_marker.png',
                scaledSize: {
                  width: 20,
                  height: 30
                }
            };
          }
            const marker = {
              'id' : eachObject['id'],
              'name' : eachObject['name'],
              'icon' : markerType,
              'lat' : eachObject['lat'],
              'lng' : eachObject['lng']
            } ;
            this.markers.push(marker);
          });
        }
      });
    });
  }

  // showing cumiliative data
  showDivision(marker) {
    this.appComponent.startLoading();
    this.selectedAsset = 'Showing Data For ' + marker['name'];
    this.backUpMarkers = this.markers;
    this.markers = [];
    this.markers.push(marker);
    this.show = !this.show;  // change the show button to show all asset button
    this.getCurrent(marker['name']); // getting current data for specific building
    this.getSoFarToday(marker['name']); // getting so far data
    this.getAverage(marker['name']); // getting average monthly data
    this.getSolarContribution(marker['name']); // getting solar contribution
    this.getAlertData(marker['name']); // getting Allert Data
    this.getEnergyValue(marker['name']); // getting generated Energy values
    this.getPerformance(marker['name']);  // getting performance data
  }
  /*for refreshing and showing all assets button" */
  showOrRefresh(valueToShow) {
   if (valueToShow === 'showAsset') {  // if value is 'show all asset'
    this.markers = this.backUpMarkers;
     this.show = !this.show;
   } else {
    this.markers = [];
    this.startGettingData();
   }
  }

  // get the currnt generation and consumption value
  getCurrent(assetName?: string) {
    const currentObserver = (assetName === null ? this.dashboardService.getCurrentStatus() :
     this.dashboardService.getCurrentStatus(assetName));
     currentObserver.subscribe(
      (data) => {
        this.powerConsumption = data['powerConsumption'];
        this.powerGeneration = data['powerGeneration'];
        this.powerUnit = data['units'];
      }
     );
  }

  getSoFarToday(assetName?: string) {
    const soFarToday = (assetName === null ? this.dashboardService.getSoFarToday() :
    this.dashboardService.getSoFarToday(assetName));
    soFarToday.subscribe(
     (data) => {
       this.generationTodayValue = data['solarGeneration'];
       this.consumptionTodayValue = data['energyConsumption'];
       this.generationUnit = data['units'];
     }
    );
  }

  getAverage(assetName?: string) {
    const average = (assetName === null ? this.dashboardService.getMonthAvg() :
    this.dashboardService.getMonthAvg(assetName));
    average.subscribe(
     (data) => {
       this.avgGenerationValue = data['solarGeneration'];
       this.generationUnit = 'kWh';
       this.avgConsumptionValue = data['energyConsumption'];
       this.consumptionUnit = 'MWh';
     }
    );
  }

  getSolarContribution(assetName?: string) {
    const solarContribution = (assetName === null ? this.dashboardService.getContribution() :
    this.dashboardService.getContribution(assetName));
    solarContribution.subscribe(
     (data) => {
        this.yesterDaySolarContribution = data['yesterday'];
        this.last30DaysSolarContribution = data['last30Days'];
     }
    );
  }

  getAlertData(assetName?: string) {
    this.alertAssetObjects = [];
    const alertDataresponse = (assetName === null ? this.dashboardService.getAlertData() :
    this.dashboardService.getAlertData(assetName));
    alertDataresponse.subscribe(
     (data) => {
     for ( let i = 0; i < Object.keys(data).length; i++) {
      this.alertAssetObjects.push(data[i]);
     }
     }
    );
  }

  getEnergyValue(assetName?: string) {
    this.graphTitle = 'Energy Generated';
    this.yAxisText = 'Energy(kWh)';
    const energyValue = (assetName === null ? this.dashboardService.getEnergyValue() :
    this.dashboardService.getEnergyValue(assetName));
    energyValue.subscribe(
     (data) => {
        const mainData = [];
        const category = [];
        if (assetName == null ) {
        this.chartUnit = data[0]['units'];
       } else {
        this.chartUnit = 'kWh';
       }
     for ( let i = 0; i < Object.keys(data).length; i++) {
         const assetNameFromResponse = data[i]['assetName'];
         const innerData = [];
         const values = data[i]['data'];
         for ( let j = 0; j < values.length; j++) {
             innerData.push(values[j]['value']);
             if (i === 1) {
                 category.push(values[j]['month']);
             }
         }
         const eachData = {
             'name' : assetNameFromResponse,
             'data' : innerData
         };
         mainData.push(eachData);
     }
     this.energyChartData = mainData;
     this.energyCategory = category;
     }
    );
  }
  getPerformance(assetName?: string) {
      this.performanceGraphTitle = 'Performance';
      this.performanceyAxisText = 'Performance Ratio(%)';
    const energyValue = (assetName === null ? this.dashboardService.getPerformance() :
    this.dashboardService.getPerformance(assetName));
    energyValue.subscribe(
     (data) => {
        const mainData = [];
        const category = [];
        this.performancechartUnit = '%';
     for ( let i = 0; i < Object.keys(data).length; i++) {
         const assetNameFromResponse = data[i]['assetName'];
         const innerData = [];
         const values = data[i]['data'];
         for ( let j = 0; j < values.length; j++) {
             innerData.push(values[j]['value']);
             if (i === 1) {
                 category.push(values[j]['month']);
             }
         }
         const eachData = {
             'name' : assetNameFromResponse,
             'data' : innerData
         };
         mainData.push(eachData);
     }
     this.performanceChartData = mainData;
     this.performanceCategory = category;
     this.appComponent.stopLoading();
     });
  }

}
