import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HighstockComponentComponent } from './highstock-component.component';

describe('HighstockComponentComponent', () => {
  let component: HighstockComponentComponent;
  let fixture: ComponentFixture<HighstockComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HighstockComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HighstockComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
