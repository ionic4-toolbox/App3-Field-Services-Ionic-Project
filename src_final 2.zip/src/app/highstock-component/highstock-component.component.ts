import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-highstock-component',
  templateUrl: './highstock-component.component.html',
  styleUrls: ['./highstock-component.component.css']
})
export class HighstockComponentComponent implements OnInit, OnChanges {
  @Input()
  dataValues = [];
  @Input()
  categories = [];
  @Input()
  graphTitle ;
  @Input()
  yAxisText;
  @Input()
  unit;
  @Input()
  wdt;
  values;
  chart: any;
  options: any;
  constructor() { }

  ngOnInit() {
    this.ifNoData();
    this.constructGraph();
   }
   ngOnChanges() {
    this.ifNoData();
    this.constructGraph();
   }
  
  ifNoData() {
    if (this.dataValues.length === 0 && this.unit === '%') {
         this.dataValues = [{'name': this.graphTitle, 'data': [0, 0, 0 , 0, 0, 0, 0 , 0, 0, 0, 0 , 0]}];
         this.categories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
         // this.performanceGraphTitle = 'Performance';
         this.yAxisText = 'Performance Ratio(%)';
    } else if ( this.dataValues.length === 0 && this.unit === 'kWh') {
        this.dataValues = [{'name': this.graphTitle, 'data':  [0, 0, 0 , 0, 0, 0, 0 , 0, 0, 0, 0 , 0]}];
        this.categories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        // this.performanceGraphTitle = 'Performance';
        this.yAxisText = 'Energy(kWh)';

    }
  }

  constructGraph() {
    console.log("data values in on changes", this.dataValues);
    
    this.options = {
      title : {text: this.graphTitle },  
       
      chart: {
        height: 350,
        type: 'column',
        width: this.wdt
        
    },
    series: this.dataValues
};

  }

  saveInstance(chartInstance) {
    this.chart = chartInstance;
  }

}
