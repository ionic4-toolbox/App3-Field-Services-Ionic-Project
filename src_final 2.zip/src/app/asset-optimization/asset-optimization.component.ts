import { Component, OnInit } from '@angular/core';
// import { Http , Response} from '@angular/http';
import { AppComponent } from 'src/app/app.component';
import { AssetOptimizationserviceService } from 'src/app/service/asset-optimizationservice.service';
import { chart } from 'highcharts';
import * as Highcharts from 'highcharts';

import { MyServiceService } from 'src/app/service/my-service.service';

@Component({
  selector: 'app-asset-optimization',
  templateUrl: './asset-optimization.component.html',
  styleUrls: ['./asset-optimization.component.css']
  
})
export class AssetOptimizationComponent implements OnInit {

    performanceGraphTitle;
    performanceyAxisText;
    performancechartUnit;
    performanceChartData = [];
    performanceCategory = [];
    efficiencyGraphTitle;
    efficiencyAxisText;
    efficiencychartUnit;
    efficiencyChartData = [];
    efficiencyCategory = [];
    energyGraphTitle;
    energyAxisText;
    energychartUnit;
    energyChartData = [];
    energyCategory = [];
    height = "100px";
    weidth= "50%";
    selected;
    TiltAngleMonth;
    TiltAngleValue;
    tiltdata;
    barChartData=[];
    barChartData1;
    barData;
  constructor(private assetOptimizationserviceService: AssetOptimizationserviceService, private appComponent: AppComponent,private userService:MyServiceService) { 

    this.userService.currentJobName.subscribe((message: any) => {

      this. onEdit(message);

    });


    
}
  onEdit(assetName){
       this.appComponent.startLoading();
       this.getPerformanceForOptimization(assetName);
       this.getOverallEfficiencyForOptimization(assetName);
       this.getEnergyGenForOptimization(assetName);    
  }
  
  optionsEff: Object;
  options: Object;

  ngOnInit() {
     this.onEdit("");
     this.userService.currentTiltAngleInfo.subscribe((tilt: any) => {

      this.getTiltAngleInformation(tilt);

      console.log("tilt get",tilt)

    });
  }


  getPerformanceForOptimization(assetName?: string) {
    this.performanceGraphTitle = 'Performance';
    this.performanceyAxisText = 'Performance Ratio(%)';
  const energyValue = (assetName === null ? this.assetOptimizationserviceService.getPerformanceForOptimization() :
  this.assetOptimizationserviceService.getPerformanceForOptimization(assetName));
  energyValue.subscribe(
   (data) => {
        console.log("performance data", data);
      const mainData = [];
      const category = [];
      this.performancechartUnit = '%';
    
   for ( let i = 0; i < Object.keys(data).length; i++) {
          
             const assetNameFromResponse = data[i]['assetName'];
            const innerData = [];
            const values = data[i]['data'];
            for ( let j = 0; j < values.length; j++) {
                innerData.push(values[j]['value']);
                if (i === 1) {
                    category.push(values[j]['month']);
                }
            }

            const eachData = {
                'name' : assetNameFromResponse,
                'data' : innerData
            };
            mainData.push(eachData);
            console.log("main data", mainData);
       
   }
   this.performanceChartData = mainData;
   this.performanceCategory = category;
  
   });
}

getOverallEfficiencyForOptimization(assetName?: string){
    this.efficiencyGraphTitle = 'Overall Efficiency';
    this.efficiencyAxisText = 'Efficiency Ratio(%)';
  const energyValue = (assetName === null ? this.assetOptimizationserviceService.getOverAllEffForOptimization() :
  this.assetOptimizationserviceService.getOverAllEffForOptimization(assetName));
  energyValue.subscribe(
   (data) => {
        console.log("efficiency data", data);
        this.efficiencychartUnit = '%';
        this.barData = data;
        var chartDataOptions = [];
        var barChartData=[];
        var chartData = [];
        console.log(this.barData[1].data.length)
      for(var i =0; i< this.barData.length;i++){
        var name = this.barData[i].sensorName;
        var dataArray =[];
        for(var j = 0; j<this.barData[i].data.length; j++){
            var dataChild =[];
            dataChild.push(this.barData[i].data[j].value);
            dataArray.push(dataChild);
        }
        var chartDataObj = {
            name : name,
            data : dataArray
        }
        chartDataOptions.push(chartDataObj);
        
    }
    this.efficiencyChartData = chartDataOptions;
    
    this.appComponent.stopLoading();
    });
}
getEnergyGenForOptimization(assetName?: string){

    this.energyGraphTitle = 'Energy Generation';
    this.energyAxisText = 'Performance Ratio(%)';
  const energyValue = (assetName === null ? this.assetOptimizationserviceService.getEnergyForOptimization() :
  this.assetOptimizationserviceService  .getEnergyForOptimization(assetName));
  energyValue.subscribe(
   (data) => {
        console.log("Energy data", data);
        this.efficiencychartUnit = '%';
        this.barData = data;
        var chartDataOptions = [];
        var barChartData=[];
        var chartData = [];
        console.log(this.barData[1].data.length)
      for(var i =0; i< this.barData.length;i++){
        var name = this.barData[i].sensorName;
        var dataArray =[];
        for(var j = 0; j<this.barData[i].data.length; j++){
            var dataChild =[];
            dataChild.push(this.barData[i].data[j].value);
            dataArray.push(dataChild);
        }
        var chartDataObj = {
            name : name,
            data : dataArray
        }
        chartDataOptions.push(chartDataObj);
        
    }
    this.energyChartData = chartDataOptions;
    //this.appComponent.stopLoading();
    });   
}

getTiltAngleInformation(tilt?: string){
  const tiltValue = (tilt === null ? this.assetOptimizationserviceService.getTiltAngleInfo() :
  this.assetOptimizationserviceService.getTiltAngleInfo(tilt));
  tiltValue.subscribe(
   (data) => {
        console.log("tilt data", data);

     this.tiltdata = data;

     console.log("@@@@@@",this.tiltdata.month);

         this.TiltAngleMonth = this.tiltdata.month;
         this.TiltAngleValue =this.tiltdata.angle.toFixed(2);
        // console.log(this.TiltAngleValue, this.TiltAngleMonth)
    //     this.efficiencychartUnit = '%';
    //     this.barData = data;
    //     var chartDataOptions = [];
    //     var barChartData=[];
    //     var chartData = [];
    //     console.log(this.barData[1].data.length)
    //   for(var i =0; i< this.barData.length;i++){
    //     var name = this.barData[i].sensorName;
    //     var dataArray =[];
    //     for(var j = 0; j<this.barData[i].data.length; j++){
    //         var dataChild =[];
    //         dataChild.push(this.barData[i].data[j].value);
    //         dataArray.push(dataChild);
    //     }
    //     var chartDataObj = {
    //         name : name,
    //         data : dataArray
    //     }
    //     chartDataOptions.push(chartDataObj);
        
    // }
    // this.energyChartData = chartDataOptions;
    //this.appComponent.stopLoading();
    }); 

}
}
