import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetOptimizationComponent } from './asset-optimization.component';

describe('AssetOptimizationComponent', () => {
  let component: AssetOptimizationComponent;
  let fixture: ComponentFixture<AssetOptimizationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetOptimizationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetOptimizationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
