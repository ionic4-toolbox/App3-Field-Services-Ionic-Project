import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RadiationMeterComponent } from './radiation-meter.component';

describe('RadiationMeterComponent', () => {
  let component: RadiationMeterComponent;
  let fixture: ComponentFixture<RadiationMeterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RadiationMeterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RadiationMeterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
