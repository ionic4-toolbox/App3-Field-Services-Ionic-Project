import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-radiation-meter',
  templateUrl: './radiation-meter.component.html',
  styleUrls: ['./radiation-meter.component.css']
})
export class RadiationMeterComponent implements OnInit {

   gaugeType = "semi";
   gaugeValue = 28.3;
   gaugeLabel = "Speed";
  constructor() { }

  ngOnInit() {
  }

}
