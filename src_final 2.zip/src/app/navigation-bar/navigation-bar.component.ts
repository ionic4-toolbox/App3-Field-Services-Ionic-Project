import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationServiceService } from '../service/navigation-service.service';


@Component({
  selector: 'app-navigation-bar',
  templateUrl: './navigation-bar.component.html',
  styleUrls: ['./navigation-bar.component.css']
})
export class NavigationBarComponent implements OnInit {

  selected = 'dash';
  constructor(private router: Router , private navService: NavigationServiceService) { }

  ngOnInit() {
    this.selected = this.navService.selectedNav;
   // this.router.navigate(['/dashboard']);
  }
  selectedNav(tab){
   this.navService.selectedNav = tab;
  }
}
