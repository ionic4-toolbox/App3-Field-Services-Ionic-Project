import { AppComponent } from './../app.component';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';
import { concat } from 'rxjs/internal/observable/concat';
import { Router } from '@angular/router';
import { AgmCoreModule } from '@agm/core';
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';
import { MatTableModule } from '@angular/material';
import { DeerServiceService } from '../service/deer-service.service';


@Component({
  selector: 'app-table-right',
  templateUrl: './table-right.component.html',
  styleUrls: ['./table-right.component.css']
})

@Pipe({
  name: 'dateFormat'
})
export class TableRightComponent implements OnInit {
  childData:Array<any> = [];
  sunData: any;
  date: any;
  date2: any;
  assetType: string;
  status:any;
  labelOptions = {

    fillColor: '#66ff66',
    /*   color: '#66ff66', 
     backgroundColor:'#66ff66',*/
    fontFamily: '',
    fontSize: '14px',
    fontWeight: 'bold',
    text: 'Some Text',

  }

greenIcon = {
  url: './../../assets/green_marker.png',
  scaledSize: {
    width: 20,
    height: 30
  }
}

redIcon = {
  url: "./../../assets/red_marker.png",
  scaledSize: {
    width: 20,
    height: 30
  }
}

 

  displayedColumns2  =  ['time',  'azimuth',  'zenith'];
  constructor(private myService: DeerServiceService,private datePipe: DatePipe, private router: Router, private appComp : AppComponent) {
    this.date = new Date();

    setInterval(() => {
      this.date = new Date();
    }, 1000);
 
    this.date2 = new Date();

    this.date2 = datePipe.transform(this.date, 'yyyy-dd-MM hh:mm:ss');
   }

   TTClick() {

    this.router.navigate(["routerMapping"]);
  }

  lat: number = 19.176108;
  lng: number = 72.990396;
  zoom: number = 19;
  public now: Date = new Date();
  markers: Array<any> = [];
  latitude: number;
  longitude: number;
  scrollwheel: any;
  latArr: any = [];
  lngArr: any = [];
  sunInfo: any = [];
  snazzyArr: Array<any> = [];
  snazzyLatitude: number;
  snazzyLongitude: number;
  snazzyAssetId: number;
  snazzyInstallationDate: any;
  snazzyName: any;
  caseString:any;
  snazzyArr2: Array<any> = [];

  ngOnInit() {
    const that = this;
    setTimeout(function() {
      that.appComp.startLoading();
    }, 30);
    console.log("Checking snazarray 1",this.snazzyArr )
    //getting sunTRack data

    this.myService.getSunTrack().subscribe((res)  =>  {

      this.sunData =  [JSON.parse(res["_body"])];

      console.log("sunData", this.sunData);
      console.log("Checking snazarray 2",this.snazzyArr )
    })

    //getChild

    this.myService.getChildData().subscribe((res)  =>  {
      
      //this.childData= [JSON.parse(res["_body"])];
      this.childData =  res.json();
      
      console.log("2 lat and lng ",this.childData);
      for (let i = 0; i < this.childData.length; i++) {
        if (this.childData[i].lat != null) {
          
            //this.markers.push({"latitude":this.childData[i].lat,"longitude":this.childData[i].lng});
           // this.snazzyArr.push({ "snazzyLatitude": this.childData[i].lat, "snazzyLongitude": this.childData[i].lng, "snazzyAssetId": this.childData[i].id, "snazzyInstallationDate": this.childData[i].commissionDate, "snazzyName": this.childData[i].name });
           

          this.snazzyArr2.push({ "snazzyLatitude": this.childData[i].lat, "snazzyLongitude": this.childData[i].lng, "snazzyAssetId": this.childData[i].id, "snazzyInstallationDate": this.childData[i].commissionDate, "snazzyName": this.childData[i].name});
        
      }
      }
      
      this.letsTry();

    })


    
 
  
    //get building
     this.myService.getBuilding().subscribe((res)  =>  {
       console.log("Checking snazarray 3",this.snazzyArr )
      this.childData =  res.json();
      console.log("childData", this.childData);
      for (let i = 0; i < this.childData.length; i++) {
        if (this.childData[i].lat != null) {
        
        
            //this.markers.push({"latitude":this.childData[i].lat,"longitude":this.childData[i].lng});
            //this.snazzyArr.push({ "snazzyLatitude": this.childData[i].lat, "snazzyLongitude": this.childData[i].lng, "snazzyAssetId": this.childData[i].id, "snazzyInstallationDate": this.childData[i].commissionDate, "snazzyName": this.childData[i].name });
       
          //  console.log("snazzy name:",this.snazzyArr[i].name);
            this.myService.checkActiveFlag(this.childData[i].name).subscribe((res2)  =>  {
  
              this.status =  res2.json();
              //console.log("status .."+ this.childData[i]);
    
              if(this.status["caseString"]=='N'){
                console.log("if");
                this.snazzyArr.push({ "snazzyLatitude": this.childData[i].lat, "snazzyLongitude": this.childData[i].lng, "snazzyAssetId": this.childData[i].id, "snazzyInstallationDate": this.childData[i].commissionDate, "snazzyName": this.childData[i].name,"mark":this.greenIcon });
       
                 
              }
              else{
                this.snazzyArr.push({ "snazzyLatitude": this.childData[i].lat, "snazzyLongitude": this.childData[i].lng, "snazzyAssetId": this.childData[i].id, "snazzyInstallationDate": this.childData[i].commissionDate, "snazzyName": this.childData[i].name,"mark":this.redIcon });
              }
              console.log("Marker  size ", this.snazzyArr);
              //console.log("stat",this.status["caseString"]);
            })
       
          
          // this.markers.push("longitude",this.childData[i].lng);
          //this.latArr.push(this.childData[i].lat);
          //this.lngArr.push(this.childData[i].lng);
         // console.log("array", this.snazzyArr); 
      }

      }
      this.appComp.stopLoading();
    } 

    )
  }
  letsTry() {
    console.log("log ",this.snazzyArr2);

      for(let m=0;m<this.snazzyArr2.length;m++){
  
        
        this.myService.checkActiveFlag(this.snazzyArr2[m].snazzyName).subscribe((res2)  =>  {
          console.log("kjahgsdkuhaslikdjhnaskdjhalksdjhkas")

      
          this.status =  res2.json();
          console.log("hi ",this.status )
          /* this.snazzyArr.push({"caseString":this.status["caseString"]}); */
          console.log("b4 ",this.snazzyArr2[m].snazzyLatitude);
          if(this.status["caseString"]=='Y'){
            console.log("iffff");
            console.log("after ",this.snazzyArr2[m].snazzyLatitude);
           // console.log(this.childData[m].lat)
            this.snazzyArr.push({ "snazzyLatitude": this.snazzyArr2[m].snazzyLatitude, "snazzyLongitude": this.snazzyArr2[m].snazzyLongitude, "snazzyAssetId": this.snazzyArr2[m].snazzyAssetId, "snazzyInstallationDate": this.snazzyArr2[m].snazzyInstallationDate, "snazzyName": this.snazzyArr2[m].snazzyName,"mark":this.greenIcon });
          }
          //console.log("stat",this.status["caseString"]);
        })
      }
  
  
  }

  checkActiveFlag(){
    console.log("in service");
    for(let l=0;l<this.snazzyArr.length;l++){
      console.log(this.snazzyArr[l].snazzyName);
      this.myService.checkActiveFlag(this.snazzyArr[l].snazzyName).subscribe((res)  =>  {

        this.status =  [JSON.parse(res["_body"])];
  
        //console.log("status", this.status);
      })

    
    }

  }

}
