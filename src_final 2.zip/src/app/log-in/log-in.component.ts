import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { LoaderServiceService } from '../service/loader-service.service';
import { AuthServiceService } from '../service/auth-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  wrongUserNamePass = false;
  constructor(private appComp: AppComponent, private loadingService: LoaderServiceService,
    private logInService: AuthServiceService, private router: Router) { }

  ngOnInit() {
    // console.log('in ng on it of log in');
    this.loadingService.stopLoading();
    const that = this;
    setTimeout(function() {
      that.appComp.loading = false;
    }, 10);
  }


  submit(formValue) {
    // console.log(formValue.value);
    this.logInService.logInValidation(formValue).subscribe(data => {
      this.wrongUserNamePass = !data;
      console.log(' this.wrongUserNamePass', this.wrongUserNamePass);
      if (data) {
        this.appComp.showLogOutbuttonMethod();
        this.router.navigate(['/dashboard/oppDashboard']);
      }
    });
  }

}
