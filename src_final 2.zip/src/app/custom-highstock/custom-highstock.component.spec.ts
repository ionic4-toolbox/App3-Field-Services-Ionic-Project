import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomHighstockComponent } from './custom-highstock.component';

describe('CustomHighstockComponent', () => {
  let component: CustomHighstockComponent;
  let fixture: ComponentFixture<CustomHighstockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomHighstockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomHighstockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
