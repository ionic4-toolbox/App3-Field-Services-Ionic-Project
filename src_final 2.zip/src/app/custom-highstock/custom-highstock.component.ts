import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-highstock',
  templateUrl: './custom-highstock.component.html',
  styleUrls: ['./custom-highstock.component.css']
})
export class CustomHighstockComponent implements OnInit {

  constructor() {
        this.options = {
            title : { text : 'AAPL Stock Price' },
            series : [{
                name : 'AAPL',
                data : [[1147651200000, 67.79],
                [1147737600000, 64.98],
                [1147824000000, 65.26]],
                tooltip: {
                    valueDecimals: 2
                }
            }]
        };

}
options: Object;

  ngOnInit() {
  }

}
