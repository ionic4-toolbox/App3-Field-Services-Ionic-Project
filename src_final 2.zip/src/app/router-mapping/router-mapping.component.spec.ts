import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterMappingComponent } from './router-mapping.component';

describe('RouterMappingComponent', () => {
  let component: RouterMappingComponent;
  let fixture: ComponentFixture<RouterMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RouterMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RouterMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
