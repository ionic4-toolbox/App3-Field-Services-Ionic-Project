import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-router-mapping',
  templateUrl: './router-mapping.component.html',
  styleUrls: ['./router-mapping.component.css']
})
export class RouterMappingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
