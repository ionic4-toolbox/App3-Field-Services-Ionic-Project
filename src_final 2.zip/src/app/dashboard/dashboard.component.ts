import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AppComponent } from '../app.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {

  constructor(private appComponent: AppComponent, private router: Router) { }
  ngOnInit() {
    }

  tabChange(data) {
   if (data.index === 0) {
    this.router.navigate(['/dashboard/oppDashboard']);
   } else if (data.index === 1) {
    this.router.navigate(['/dashboard/managementDashboard']);
   }
  }

}
