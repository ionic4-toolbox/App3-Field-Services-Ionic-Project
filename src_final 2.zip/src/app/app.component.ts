import { Component, OnInit, OnChanges, AfterViewInit } from '@angular/core';
import {DomSanitizer} from '@angular/platform-browser';
import {MatIconRegistry} from '@angular/material';
import { LoaderServiceService } from './service/loader-service.service';
import { AuthServiceService } from './service/auth-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements  OnInit {
  public loading = true;
  showLogOutButton;
  constructor(private loadingService: LoaderServiceService , private authService: AuthServiceService,
  private router: Router) { }
  ngOnInit() {
   // this.loading = true;
  // this.showLogOutButton = this.authService.isLoggedIn();
  }
 showLogOutbuttonMethod() {
  this.showLogOutButton = true;
 }
  stopLoading() {
    this.loading = false;
  }

  startLoading() {
    this.loading = true;
  }

  getLoading() {
    return this.loading;
  }

  logOut() {
    this.authService.logOut();
    this.router.navigate(['/login']);
  }

}
