import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { MyServiceService } from 'src/app/service/my-service.service';
import { FormGroup, FormControl, Validators, FormsModule, FormBuilder, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-dropdown',
  templateUrl: './dropdown.component.html',
  styleUrls: ['./dropdown.component.css']
})
export class DropdownComponent implements OnInit {

  drpdwnChild1Train: any;
  assetName: any;
  assetId: any;
  show2: any;
  show1: boolean;
  form: FormGroup;
  assetId1;
  drpdwnData1;
  drpdwnData2;
  drpdwnData3;
  drpdwnData4;

  drpdwnChild1 = [];
  drpdwnChild2 = [];

  

  public show = false;
  public buttonName: any = 'Show';

  showTrain = false;

  drpdwnselected: any;

  Select: any;
  Temp;

  constructor(private userService: MyServiceService, private fb: FormBuilder) {

    this.form = this.fb.group({

      assetId1: [null],
      assetId2: [null],
      assetId3: [null],
      assetId4: [null]


    });

    this.userService.currentJobName.subscribe((message: any ) => {

      this.drpdwnselected = message;
      if (message) {
        this.Select = message;
      } else {
        this.Select = 'Select Asset';
      }
    });


  }

  ngOnInit() {
    console.log('"hii"');

    console.log('"drpdwnselected"', this.drpdwnselected);
    this.getDropDownData1();
    this.getDropDownData2();
    this.getDropDownData3();
    this.getDropDownData4();


  }


  getDropDownData1() {
    console.log('"hiii"');
    this.userService.getDrpdown1()
      .subscribe(
        returnData => {
          this.drpdwnData1 = returnData;
          console.log('"data1"', this.drpdwnData1);
        }
      );
  }

  getDropDownData2() {

    this.userService.getDrpdown2()
      .subscribe(
        returnData => {
          this.drpdwnData2 = returnData;
          console.log('"data2"', this.drpdwnData2);
        }
      );
  }

  getDropDownData3() {

    this.userService.getDrpdown3()
      .subscribe(
        returnData => {
          this.drpdwnData3 = returnData;
          console.log('"data3"', this.drpdwnData3);
        }
      );
  }

  getDropDownData4() {
    this.userService.getDrpdown4()
      .subscribe(
        returnData => {
          this.drpdwnData4 = returnData;
          console.log('"data4"', this.drpdwnData4);
        }
      );
  }



  getDropDown(event) {
    console.log(event.assetId);
    this.assetId1 = event.assetId1;
    this.drpdwnChild1 = [];

    // this.form.get('assetId1').setValue(this.assetId1);
    if (event.assetId1 === 'Energy') {

      this.show = !this.show;

      if (this.show) {
        this.buttonName = 'Hide';
      } else {
        this.buttonName = 'Show';
      }
      for (let i = 0; i <= 1; i++) {

        this.drpdwnChild1.push(this.drpdwnData2[i]);


        console.log('"this.drpdwnChild1"', this.drpdwnChild1);

      }

    } else {
      this.drpdwnChild1Train = this.drpdwnData2[2];
      console.log(this.drpdwnChild1Train.name);
      this.showTrain = true;
    }


  }


  getDropDown2(event) {


    if (event.assetId2 === 'Solar-PV') {




      this.show1 = !this.show1;

      if (this.show) {
        this.buttonName = 'Hide';
      } else {
        this.buttonName = 'Show';
      }

    } else {
      this.Temp = event.assetId2;

     console.log('"temp"', this.Temp);

     this.userService.setJobName(this.Temp);
    }

    // localStorage.setItem("assetId",event.assetId2);
    // console.log("asset",localStorage.getItem("assetId"));
  }



  getDropDown3(event) {

    if (event.assetId3 === 'Yosemite') {

    this.show2 = !this.show2;

    if (this.show) {
      this.buttonName = 'Hide';
    } else {
      this.buttonName = 'Show';
    }
    } else {

    console.log('"verglades"', event.assetId3);
    this.Temp = event.assetId3;

    console.log('"this.temp"', event.assetId3);
    this.userService.setJobName(this.Temp);

    this.userService.setTiltAngle(event.lat);

    this.userService.setlong(event.value.lng);
    console.log("lat",event.lat)

   }



  }

 assetSelected(e) {
  console.log('"asset  name selected"', e);


  
  this.userService.setJobName(e.value.name);

this.userService.setTiltAngle(e.value.lat);

this.userService.setlong(e.value.lng);
console.log("lat",e.value.lat)

}

}
