import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import { AppComponent } from './app.component';
import { OperationalDashboardComponent } from './operational-dashboard/operational-dashboard.component';
import {MatIconModule} from '@angular/material/icon';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import {MatTabsModule} from '@angular/material/tabs';
import { AgmCoreModule } from '@agm/core';
import { AgmJsMarkerClustererModule } from '@agm/js-marker-clusterer';
import { AgmSnazzyInfoWindowModule } from '@agm/snazzy-info-window';
import { HttpClientModule } from '@angular/common/http';
import { GaugeModule } from 'angular-gauge';
import { RadiationMeterComponent } from './radiation-meter/radiation-meter.component';
import { NgxGaugeModule } from 'ngx-gauge';
import { ChartModule } from 'angular2-highcharts';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { GaugeChartComponent } from './gauge-chart/gauge-chart.component';
import { ColumnChartComponent } from './column-chart/column-chart.component';
import { AssetOptimizationComponent} from './asset-optimization/asset-optimization.component';
import { LoadingModule } from 'ngx-loading';
import {MatFormField} from '@angular/material';
import { MyServiceService } from './service/my-service.service';
import { IncidentComponent } from './incident/incident.component';
import {DropdownComponent} from './dropdown/dropdown.component';
import {HighstockComponentComponent} from './highstock-component/highstock-component.component';
// import { MyserviceService } from './myservice.service';
// import { ManagementDashComponent } from './management-dash/management-dash.component';
// import { ComparativePerformanceComponent } from './comparative-performance/comparative-performance.component';
// import { EnergyCostSavingComponent } from './energy-cost-saving/energy-cost-saving.component';
import { MatCardModule} from '@angular/material';

import {MatSelectModule} from '@angular/material/select';
import { CustomHighstockComponent } from './custom-highstock/custom-highstock.component';
import { ManagementDashboardComponent } from './management-dashboard/management-dashboard.component';
import { PerformanceTableComponent} from './performance-table/performance-table.component'
import { LogInComponent } from './log-in/log-in.component';

import { AuthGuard } from './service/auth-guard.service';

import { DatePipe } from '@angular/common';

import {MatTableModule,MatPaginatorModule} from '@angular/material';

import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatExpansionModule} from '@angular/material/expansion';

import { NgxSpinnerModule } from 'ngx-spinner';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {MatMenuModule} from '@angular/material/menu';

 import {DialogModule} from 'primeng/dialog';
import { HighchartComponentComponent } from './highchart-component/highchart-component.component';
// import { TableRightComponent } from './table-right/table-right.component';
import { RouterMappingComponent } from './router-mapping/router-mapping.component';
import { TableRightComponent } from './table-right/table-right.component';
import { HttpModule } from '@angular/http';
import { WeatherMonitoringComponent } from './weather-monitoring/weather-monitoring.component';


// import { ManagementdashboardComponent } from './managementdashboard/managementdashboard.component';
// import {MatGridListModule} from '@angular/material/grid-list';

declare var require: any;
const routes: Routes = [
  { path: 'dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
    children : [
      { path: 'oppDashboard',
      component: OperationalDashboardComponent
      },
      { path: 'managementDashboard',
      component: ManagementDashboardComponent
      },
      { path: '',
      component: OperationalDashboardComponent
      },
      
    ]
  },
  {
    path:'assetvisibility',
    component:TableRightComponent,
    canActivate: [AuthGuard],
  },
  { path: 'incident', 
  canActivate: [AuthGuard],
  component:  IncidentComponent},
  {
    path: 'asset-optimization',
    canActivate: [AuthGuard],
    component: AssetOptimizationComponent
  },
  { path: 'assetmonitor',
  canActivate: [AuthGuard], 
  component: PerformanceTableComponent },
  {
    path: 'login',
    component: LogInComponent,
  },
  { path: 'routerMapping',
  canActivate: [AuthGuard],
  component:RouterMappingComponent
  },
  { path: '',
  pathMatch: 'full',
  redirectTo: '/login'
  },
  { path: '**',
  pathMatch: 'full',
  redirectTo: '/login'
  }
  
  // 
  
];
@NgModule({
  declarations: [
    AppComponent,
    AssetOptimizationComponent,
    IncidentComponent,
    DropdownComponent,
    OperationalDashboardComponent,
    NavigationBarComponent,
    DashboardComponent,
    HighstockComponentComponent,
    RadiationMeterComponent,
    GaugeChartComponent,
    PerformanceTableComponent,
    ColumnChartComponent,
    CustomHighstockComponent,
    ManagementDashboardComponent,
    ManagementDashboardComponent,
    LogInComponent,
    HighchartComponentComponent,
    TableRightComponent,
    RouterMappingComponent,
    WeatherMonitoringComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    LoadingModule,
    MatProgressBarModule,
    AgmJsMarkerClustererModule,
    AgmSnazzyInfoWindowModule,
    FormsModule,
    RouterModule.forRoot(routes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDTnnlhDW71zaEyVichmDouZaH7p0_Of_g'
    }),
    HttpClientModule,
    HttpModule,
    GaugeModule.forRoot(),
    NgxGaugeModule,
    MatCardModule,
    MatTableModule,
    MatSelectModule,
    MatExpansionModule,
    MatPaginatorModule,
    NgxSpinnerModule,
    MatMenuModule,
    DialogModule,
    ReactiveFormsModule,
    ChartModule.forRoot(require('highcharts'), require('highcharts/highcharts-more'),
    require('highcharts/modules/solid-gauge'), require('highcharts/modules/exporting'),
    require('highcharts/modules/drilldown'), require('highcharts/modules/stock'))
  ],
  providers: [MyServiceService,DatePipe],
  exports: [ RouterModule ],
  bootstrap: [AppComponent]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);
