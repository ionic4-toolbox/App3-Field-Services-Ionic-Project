import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HighchartComponentComponent } from './highchart-component.component';

describe('HighchartComponentComponent', () => {
  let component: HighchartComponentComponent;
  let fixture: ComponentFixture<HighchartComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HighchartComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HighchartComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
