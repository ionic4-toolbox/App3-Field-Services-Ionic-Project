import { Component, OnInit, Input,OnChanges } from '@angular/core';
// import Highcharts = require('highcharts');

@Component({
  selector: 'app-highchart-component',
  templateUrl: './highchart-component.component.html',
  styleUrls: ['./highchart-component.component.css']
})
export class HighchartComponentComponent implements OnInit {

  @Input()
  dataValues= [];
  chart: any;
  graphTitle;
  options: any;
  constructor() { }

  ngOnInit() {

    this.constructGraph();
  }


  ngOnChanges() {
   
    this.constructGraph();
  }

  
  
  constructGraph() {

    console.log("data values in on changes", this.dataValues);
    
    this.options = {
      title : {text: this.graphTitle },  
       
      chart: {
        height: 350,
        type: 'line',
        width:1200,
        
    },
    xAxis: {
          type: 'datetime',
          dateTimeLabelFormats: {
            month: '%e. %b',
            year: '%b'
          },
          title: {
            text: 'Date'
          }
        },
          yAxis: {
      title: {
        text: 'Threshold Breach Count'
      },
      credits: {
            enabled: false
          },
          tooltip: {
                headerFormat: '<b>{series["name"]}</b><br>',
                pointFormat: '{point.x:%e. %b}: {point.y:.2f}'
              },
              plotOptions: {
                    spline: {
                      marker: {
                        enabled: true
                      }
                    }
                  },
              

      min: 0
    },

    series: this.dataValues
};



  }
  saveInstance(chartInstance) {
    this.chart = chartInstance;
  }


}
