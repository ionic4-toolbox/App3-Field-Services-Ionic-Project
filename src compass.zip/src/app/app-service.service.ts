import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class AppServiceService {

  constructor( private http : Http ) { }

  getData(url:string) {
    this.http.get(url)
    .map(response => response.json)
    .catch( (error:Response) =>{
      return Observable.throw(error);
    } );
  }

}
