import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
//import {GaugesModule} from 'ng-canvas-gauges';
import { AppComponent } from './app.component';
import { CustomCompassComponent } from './custom-compass/custom-compass.component';
import { HttpModule } from '@angular/http';
import { ChartModule } from 'angular-highcharts';
import { CustomThermometerComponent } from './custom-thermometer/custom-thermometer.component';
import { CustomSpeedometerComponent } from './custom-speedometer/custom-speedometer.component';
import { NgxGaugeModule } from 'ngx-gauge';


@NgModule({
  declarations: [
    AppComponent,
    CustomCompassComponent,
    CustomThermometerComponent,
    CustomSpeedometerComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    ChartModule,
    NgxGaugeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
