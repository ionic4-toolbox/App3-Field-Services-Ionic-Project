import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomSpeedometerComponent } from './custom-speedometer.component';

describe('CustomSpeedometerComponent', () => {
  let component: CustomSpeedometerComponent;
  let fixture: ComponentFixture<CustomSpeedometerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomSpeedometerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomSpeedometerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
