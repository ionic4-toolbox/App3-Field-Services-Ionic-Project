import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-speedometer',
  templateUrl: './custom-speedometer.component.html',
  styleUrls: ['./custom-speedometer.component.css']
})
export class CustomSpeedometerComponent implements OnInit {

  gaugeType = "semi";
  gaugeValue = 28.3;
  gaugeLabel = "Speed";
  gaugeAppendText = "km/hr";

  gaugeType2 = "full";
  gaugeValue2 = 90;
  gaugeLabel2 = "Humidity";
  gaugeAppendText2 = "%";

  thresholdConfig = {
    '0': {color: 'green'},
    '50': {color: 'orange'},
    '80': {color: 'red'}
};

  constructor() { }

  ngOnInit() {
    setInterval(() => this.change(), 5000);
  }

 change(){
  this.gaugeValue2 = Math.floor(Math.random() * 100+1)
  this.gaugeValue = Math.floor(Math.random() * 100+1)
  }

}
