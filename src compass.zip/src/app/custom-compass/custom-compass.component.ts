import { Chart } from 'angular-highcharts';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';


declare var  $:any;
@Component({
  selector: 'app-custom-compass',
  templateUrl: './custom-compass.component.html',
  styleUrls: ['./custom-compass.component.css']
})
export class CustomCompassComponent implements OnInit {

  //@ViewChild('canvas') canvas: ElementRef;
  constructor() { }
  img = null;
  needle = null;
	ctx = null;
  degrees = 0;
  rotation='rotate(0 100 100)';

ngOnInit() {

    // var canvas=<HTMLCanvasElement>document.getElementById('canvas');
    // if (canvas.getContext('2d')) {
    //   this.ctx = canvas.getContext('2d');
    //   //console.log("this.ctx",this.ctx);

    //   this.needle = new Image();
    //   this.needle.src = '../assets/needle.png';
    //   console.log("this.needle",this.needle);

    //   this.img = new Image();
    //    this.img.onload = ()=>{
    //     this.imgLoaded();
    //    }
    //    this.img.src = '../assets/compass.png';
    // }else {
    //   		alert("Canvas not supported!");
    //  }
    setInterval(() => this.transit(), 5000);
    }

    imgLoaded(){
//this.ctx.drawImage(this.img, 0, 0);
   //   this.ctx.drawImage(this.needle, -100, -100);
     // this.draw();
     //setInterval(this.draw, 2000);
    // setInterval(() => this.draw(), 2000);
    }

  //    draw() {

  //     this.clearCanvas();
    
  //     // Draw the compass onto the canvas
  //     this.ctx.drawImage(this.img, 0, 0);
    
  //     // Save the current drawing state
  //     this.ctx.save();
    
  //     // Now move across and down half the 
  //    this.ctx.translate(100, 100);
    
  //     // Rotate around this point
  //     this.ctx.rotate(this.degrees * (Math.PI / 180));
    
  //     // Draw the image back and up
  //     this.ctx.drawImage(this.needle, -100, -100);
    
  //     // Restore the previous drawing state
  //     this.ctx.restore();
    
  //     // Increment the angle of the needle by 5 degrees
  //     this.degrees += 6;
  //   }

  //   clearCanvas() {
  //    this.ctx.clearRect(0, 0, 200, 200);
  //  }

   transit(){
     let rotate =Math.floor( (Math.random() * 360 +1));
     console.log("rotate",rotate);
     this.rotation ='rotate('+ rotate +' 90 100)';
   }


 }