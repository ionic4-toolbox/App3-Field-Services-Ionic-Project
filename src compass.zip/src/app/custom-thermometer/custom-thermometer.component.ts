import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-thermometer',
  templateUrl: './custom-thermometer.component.html',
  styleUrls: ['./custom-thermometer.component.css']
})
export class CustomThermometerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
