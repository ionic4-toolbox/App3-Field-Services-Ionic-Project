import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import { AppComponent } from './app.component';
import { OperationalDashboardComponent } from './operational-dashboard/operational-dashboard.component';
import {MatIconModule} from '@angular/material/icon';
import { NavigationBarComponent } from './navigation-bar/navigation-bar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import {MatTabsModule} from '@angular/material/tabs';
import { AgmCoreModule } from '@agm/core';
import { HttpClientModule } from '@angular/common/http';
import { GaugeModule } from 'angular-gauge';
import { RadiationMeterComponent } from './radiation-meter/radiation-meter.component';
import { NgxGaugeModule } from 'ngx-gauge';
import { ChartModule } from 'angular2-highcharts';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { GaugeChartComponent } from './gauge-chart/gauge-chart.component';

declare var require: any;
const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'oppDashboard', component: OperationalDashboardComponent }
];
@NgModule({
  declarations: [
    AppComponent,
    OperationalDashboardComponent,
    NavigationBarComponent,
    DashboardComponent,
    RadiationMeterComponent,
    GaugeChartComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    RouterModule.forRoot(routes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDTnnlhDW71zaEyVichmDouZaH7p0_Of_g'
    }),
    HttpClientModule,
    GaugeModule.forRoot(),
    NgxGaugeModule,
    ChartModule.forRoot(require('highcharts'), require('highcharts/highcharts-more'),
    require('highcharts/modules/solid-gauge'), require('highcharts/modules/exporting'),
    require('highcharts/modules/drilldown'))
  ],
  providers: [],
  exports: [ RouterModule ],
  bootstrap: [AppComponent]
})
export class AppModule { }
platformBrowserDynamic().bootstrapModule(AppModule);
