import { Component, OnInit, OnChanges, Input } from '@angular/core';

@Component({
  selector: 'app-gauge-chart',
  templateUrl: './gauge-chart.component.html',
  styleUrls: ['./gauge-chart.component.css']
})
export class GaugeChartComponent implements OnInit, OnChanges {

 @Input()
  value: Number;
  chart: any;
  options: any;
  ngOnInit() {
  }

  ngOnChanges() {
    this.ChangeGaugeValue();
  }

  constructor() {
    this.options = {
      chart: {
        type: 'solidgauge',
      },
      pane: {
        center: ['55%', '100%'],
        size: '200%',
        startAngle: -90,
        endAngle: 90,

        background: {
          backgroundColor: '#41505a',
          innerRadius: '60%',
          outerRadius: '100%',
          shape: 'arc'
        }
      },
      title: 'gauge',
      tooltip: {
        enabled: true
      },
      yAxis: {
        stops: [
          // [0.1, '#55BF3B'], // green
          // [0.5, '#DDDF0D'], // yellow
          // [0.9, '#DF5353'] // red
          [0.9, '#8ad8d6'], // blue
        ],
        lineWidth: 0,
         minorTickInterval: null,
         tickPixelInterval: 400,
         lineColor: 'transparent',
         tickWidth: 0,
        title: {
          y: 10,
          text: 'Generation'
        },
        labels: {
          y: 10
        },
        min: 0,
        max: 100,
      },
      plotOptions: {
        solidgauge: {
          radius: '100%',
          innerRadius: '60%',
          dataLabels: {
            y: 20,
            borderWidth: 0,
            useHTML: true,
          }
        }
      },
      credits: {
        enabled: false
      },
      series: [{
        name: 'Generation',
        data: [0],
        dataLabels: {
          format: '<div style = "text-align:center"><span style = " font-weight: 300; font-size:15px;color:'  +
            (('green' && 'black') || 'black') +
            '">{y}</span><br/>' +
            '<span style = "font-size:12px;color:black; font-weight: 300">%</span></div>'
        },
        tooltip: {
          valueSuffix: '%'
        }
      },
      {
        // name: 'arrow',
        // type: 'gauge',
        // data: [0],
        // enableMouseTracking: false
    }]
    };
  }
  saveInstance(chartInstance) {
    this.chart = chartInstance;
  }
  ChangeGaugeValue() {
    if (this.chart !== undefined) {
    const point1 = this.chart.series[0].points[0];
    // const point2 = this.chart.series[1].points[0];
    point1.update(this.value);
    // point2.update(this.value);
    }
  }

}
