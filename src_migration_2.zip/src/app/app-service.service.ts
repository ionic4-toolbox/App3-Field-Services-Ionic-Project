import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AppServiceService {

  constructor( private http: HttpClient) { }

  doPost(url: string , body: any , httpOptions: Object) {
    return this.http.post(url, body, httpOptions);
}
  doGet(url: string, httpOptions?: Object) {
    return (httpOptions !== null ) ? (this.http.get(url, httpOptions)) : (this.http.get(url)) ;
  }
}
