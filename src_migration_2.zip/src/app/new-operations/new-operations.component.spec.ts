import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewOperationsComponent } from './new-operations.component';

describe('NewOperationsComponent', () => {
  let component: NewOperationsComponent;
  let fixture: ComponentFixture<NewOperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewOperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
