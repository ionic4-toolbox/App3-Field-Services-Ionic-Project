import { Injectable } from '@angular/core';
import { AppServiceService } from '../app-service.service';
import { HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DashboardServiceService {

  // cumilative
  tokenUrl = 'https://fcb7ec9a-3d36-4fb6-9ed2-7c5e7d671f11.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token';
  smartCityUrl = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/smartcityassets';
  smartCityAssetChild = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/smartcityassetschild';
  solarAssetLocation = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/solarAssetLocation';
  solarAssetBuilding = 'https://predix-asset.run.aws-usw02-pr.ice.predix.io/solarAssetBuilding';
  currentPowerURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getCurrentPower';
  soFarTodayURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getCurrentEnergy';
  monthAvgEtodURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getMonthAvgEtod';
  contributionURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getContribution';
  alertDataURL = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAlerts';

  // asset wise
  alertDataURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetAlerts?assetName=';
  alertMsg = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/alertMessagePop?assetName=';
  currentPowerURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetCurrentPower';
  monthAvgEtodURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetMonthAvgEtod';
  soFarTodayURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetCurrentEnergy';
  contributionURLAsset = 'https://prod-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/getAssetContribution';
  constructor(private appService: AppServiceService) { }

getToken() {
    const tokenBody = 'app_client_id=hack_client&grant_type=client_credentials';
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type':  'application/x-www-form-urlencoded',
        'authorization': 'Basic aGFja19jbGllbnQ6aGFja19jbGllbnQ='
      })
    };
   return this.appService.doPost(this.tokenUrl, tokenBody, httpOptions);

}

getSmartCityAssets(assetHeaders) {
  return this.appService.doGet(this.smartCityUrl, assetHeaders);
}

getSmartcityAssetschild(assetHeaders) {
 return this.appService.doGet(this.smartCityAssetChild, assetHeaders);
}

getSolarAssetLocation(assetHeaders) {
  return this.appService.doGet(this.solarAssetLocation, assetHeaders);
}

getSolarAssetBuilding(assetHeaders) {
  return this.appService.doGet(this.solarAssetBuilding, assetHeaders);
}
getAlertStatus(assetName) {
  return this.appService.doGet(this.alertMsg + assetName);
}
getCurrentStatus(assetName?: string) {
  if (assetName == null) {
  return this.appService.doGet(this.currentPowerURL);
 } else {
  return this.appService.doGet(this.currentPowerURLAsset + '?assetName' + '=' + assetName);
 }
}
getSoFarToday(assetName?: string) {
  if (assetName == null) {
  return this.appService.doGet(this.soFarTodayURL);
 } else {
  return this.appService.doGet(this.soFarTodayURLAsset + '?assetName' + '=' + assetName);
 }
}

getMonthAvg(assetName?: string) {
  if (assetName == null) {
  return this.appService.doGet(this.monthAvgEtodURL);
 } else {
  return this.appService.doGet(this.monthAvgEtodURLAsset + '?assetName' + '=' + assetName);
 }
}

getContribution(assetName?: string) {
  if (assetName == null) {
    return this.appService.doGet(this.contributionURL);
   } else {
    return this.appService.doGet(this.contributionURLAsset + '?assetName' + '=' + assetName);
   }
}

getAlertData(assetName?: string) {
  if (assetName == null) {
    return this.appService.doGet(this.alertDataURL);
   } else {
    return this.appService.doGet(this.alertDataURLAsset + '?assetName' + '=' + assetName);
   }
}

}
