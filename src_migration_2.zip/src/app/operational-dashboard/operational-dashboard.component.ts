import { Component, OnInit } from '@angular/core';
import { DashboardServiceService } from '../service/dashboard-service.service';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-operational-dashboard',
  templateUrl: './operational-dashboard.component.html',
  styleUrls: ['./operational-dashboard.component.css']
})
export class OperationalDashboardComponent implements OnInit {

  lat =  19.175444 ;
  lng = 72.990211;
  zoom = 15;
  assetHeaders = {} ;
  assets = [];
  markers = [];
  selectedAsset = 'Showing Cumulative Data For All Assets';
  backUpMarkers: any;
  show = false; // default show the refresh button
  powerConsumption = 0;
  powerGeneration = 0;
  powerUnit = 'kW';
  generationTodayValue = 0;
  consumptionTodayValue = 0;
  avgGenerationValue = 0;
  generationUnit = 'kWh';
  avgConsumptionValue = 0;
  consumptionUnit = 'MWh';
  yesterDaySolarContribution = 0;
  last30DaysSolarContribution = 0;
  alertAssetObjects = [];

  constructor(private dashboardService: DashboardServiceService) { }
  ngOnInit() {
    this.getToken();
    this.getCurrent();
    this.getSoFarToday();
    this.getAverage();
    this.getSolarContribution();
    this.getAlertData();
  }
  getToken() {
    this.dashboardService.getToken().subscribe(
      // setting the header from token object
     (data) => {
       const token = 'bearer ' + data['access_token'];
       this.assetHeaders = {
         headers: new HttpHeaders({
           'Predix-Zone-Id': '69cf0edb-2ba7-40fe-84e3-614a61fe46f0',
           'authorization': token,
           'Content-Type': 'application/json'
         })
       };
        this.getAssetData();
     }
   );
  }
  getAssetData() {
    this.dashboardService.getSmartCityAssets(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.getAssetChildData();
      }
    );
  }

  getAssetChildData() {
    this.dashboardService.getSmartcityAssetschild(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.getAssetLocationData();
      }
    );
  }
  getAssetLocationData() {
    this.dashboardService.getSolarAssetLocation(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.getAssetBuildingData();
      }
    );
  }
  getAssetBuildingData() {
    this.dashboardService.getSolarAssetBuilding(this.assetHeaders).subscribe(
      (data) => {
        this.assets.push(data);
       // console.log(this.assets);
        this.constructMarkers();
      }
    );
  }

  // setting the markers
  constructMarkers() {
    this.assets.forEach(element => {
      element.forEach(eachObject => {
        if (eachObject.hasOwnProperty('lat') && eachObject.hasOwnProperty('lng')) {
          let markerType;

         this.dashboardService.getAlertStatus(eachObject['name']).subscribe(
          (data) => {
            console.log("asset", data);
            if (data['caseString'] === 'N') {
              markerType = 'http://www.googlemapsmarkers.com/v1/S/228B22/';
            } else {
              markerType = 'http://www.googlemapsmarkers.com/v1/S/FF0000/';
              // alert markers
            }
            const marker = {
              'id' : eachObject['id'],
              'name' : eachObject['name'],
              'icon' : markerType,
              'lat' : eachObject['lat'],
              'lng' : eachObject['lng']
            } ;
            this.markers.push(marker);
          });
        }
      });
    });
   // console.log("Markers", this.markers);
  }

  // showing cumiliative data
  showDivision(marker) {
    this.selectedAsset = 'Showing Data For ' + marker['name'];
    this.backUpMarkers = this.markers;
    this.markers = [];
    this.markers.push(marker);
   // console.log("this.markers", this.markers);
    this.show = !this.show;  // change the show button to show all asset button
    this.getCurrent(marker['name']); // getting current data for specific building
    this.getSoFarToday(marker['name']); // getting so far data
    this.getAverage(marker['name']); // getting average monthly data
    this.getSolarContribution(marker['name']); // getting solar contribution
    this.getAlertData(marker['name']); // getting Allert Data
  }
  /*for refreshing and showing all assets button" */
  showOrRefresh(valueToShow) {
  // console.log("in show or refresh");
   if (valueToShow === 'showAsset') {
    this.markers = this.backUpMarkers;
     this.show = !this.show;
   } else {
    this.markers = [];
    this.getToken();
   }
  }

  // get the currnt generation and consumption value
  getCurrent(assetName?: string) {
    const currentObserver = (assetName === null ? this.dashboardService.getCurrentStatus() :
     this.dashboardService.getCurrentStatus(assetName));
     currentObserver.subscribe(
      (data) => {
       // console.log("data of current", data);
        this.powerConsumption = data['powerConsumption'];
        this.powerGeneration = data['powerGeneration'];
        this.powerUnit = data['units'];
      }
     );
  }

  getSoFarToday(assetName?: string) {
    const soFarToday = (assetName === null ? this.dashboardService.getSoFarToday() :
    this.dashboardService.getSoFarToday(assetName));
    soFarToday.subscribe(
     (data) => {
      // console.log("data so far", data);
       this.generationTodayValue = data['solarGeneration'];
       this.consumptionTodayValue = data['energyConsumption'];
       this.generationUnit = data['units'];
     }
    );
  }

  getAverage(assetName?: string) {
    const average = (assetName === null ? this.dashboardService.getMonthAvg() :
    this.dashboardService.getMonthAvg(assetName));
    average.subscribe(
     (data) => {
      // console.log("data getAverage", data);
       this.avgGenerationValue = data['solarGeneration'];
       this.generationUnit = 'kWh';
       this.avgConsumptionValue = data['energyConsumption'];
       this.consumptionUnit = 'MWh';
     }
    );
  }

  getSolarContribution(assetName?: string) {
    const solarContribution = (assetName === null ? this.dashboardService.getContribution() :
    this.dashboardService.getContribution(assetName));
    solarContribution.subscribe(
     (data) => {
      // console.log("data getContruibution", data);
        this.yesterDaySolarContribution = data['yesterday'];
        this.last30DaysSolarContribution = data['last30Days'];
     }
    );
  }

  getAlertData(assetName?: string) {
    console.log("length",this.alertAssetObjects.length);
    const alertDataresponse = (assetName === null ? this.dashboardService.getAlertData() :
    this.dashboardService.getAlertData(assetName));
    alertDataresponse.subscribe(
     (data) => {
       console.log("alert data each object", data);
     for ( let i = 0; i < 5; i++) {
      this.alertAssetObjects.push(data[i]);
     }
     }
    );
  }

}
