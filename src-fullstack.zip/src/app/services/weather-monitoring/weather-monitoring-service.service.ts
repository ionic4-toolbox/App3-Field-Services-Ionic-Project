import { GenericServiceService } from './../generic-service/generic-service.service';
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class WeatherMonitoringServiceService {
url: string = 'https://dev-digitalseer-ms.run.aws-usw02-pr.ice.predix.io/' +
  'hitSolarRadiationLink?longitude=19&latitude=72&apiKey=cdYGEEvqjiU6sWcfmlGwPJyBJeHJhot3';

private forRadiation = 'forRadiation';
constructor(private genericService: GenericServiceService) {
}

getBackEndUrls() {
   return this.genericService.getData(this.url);
}
}
