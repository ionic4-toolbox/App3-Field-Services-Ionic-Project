import { TestBed, inject } from '@angular/core/testing';

import { WeatherMonitoringServiceService } from './weather-monitoring-service.service';

describe('WeatherMonitoringServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WeatherMonitoringServiceService]
    });
  });

  it('should be created', inject([WeatherMonitoringServiceService], (service: WeatherMonitoringServiceService) => {
    expect(service).toBeTruthy();
  }));
});
