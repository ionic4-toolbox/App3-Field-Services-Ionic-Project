import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { NotFoundError } from '../../common/not-found-error';
import { BadRequestError } from '../../common/bad-request-error';
import { AppError } from '../../common/app-error';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

@Injectable()
export class GenericServiceService {
  constructor(public http: Http) {
  }
  getData (url) {
    console.log(url);
    return this.http.get(url)
    .map(response => response.json())
    .catch((error: Response) => {
      if (error.status === 404) {
        return Observable.throw(new NotFoundError());
        } else if (error.status === 400) {
        return Observable.throw(new BadRequestError());
      } else {
        return Observable.throw(new AppError(error));
      }
    });
 }
}
