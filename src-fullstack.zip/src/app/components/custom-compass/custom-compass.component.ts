import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-custom-compass',
  templateUrl: './custom-compass.component.html',
  styleUrls: ['./custom-compass.component.css']
})
export class CustomCompassComponent implements OnInit {

  // @ViewChild('div1') div1: ElementRef;
  windVelocity: any;
  constructor() { }

  ngOnInit() {
    this.constructGauge();
  }
  constructGauge() {
    this.windVelocity =  {
      chartType: 'Gauge',
      dataTable: [
        ['Label', 'Value'],
        ['velocity', 280 ]
      ],
      options: {
        animation: {easing: 'out'},
        width: 300, height: 300,
        greenFrom: 100, greenTo: 400,
        yellowFrom: 0, yellowTo: 100,
        redFrom: 400, redTo: 500,
        minorTicks: 6,
        min: 0, max: 360,
        majorTicks: ['0', '60', '120', '180', '240', '360'],
        greenColor: '#d0e9c6'
      }
    };
  }

}
