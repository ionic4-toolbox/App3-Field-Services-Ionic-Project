import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomCompassComponent } from './custom-compass.component';

describe('CustomCompassComponent', () => {
  let component: CustomCompassComponent;
  let fixture: ComponentFixture<CustomCompassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomCompassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomCompassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
