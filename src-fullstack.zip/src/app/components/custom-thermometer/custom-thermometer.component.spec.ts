import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomThermometerComponent } from './custom-thermometer.component';

describe('CustomThermometerComponent', () => {
  let component: CustomThermometerComponent;
  let fixture: ComponentFixture<CustomThermometerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomThermometerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomThermometerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
