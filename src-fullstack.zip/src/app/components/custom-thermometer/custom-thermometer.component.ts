import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-custom-thermometer',
  templateUrl: './custom-thermometer.component.html',
  styleUrls: ['./custom-thermometer.component.css']
})
export class CustomThermometerComponent implements OnInit {
  width1 = 60;
  height1 = 40;
  width = 600;
  height = 400;
   max = 50;
   value = 100;
   min = 0;
    id = 'chart1';
    type = 'column2d';
    dataFormat = 'json';
    dataSource;
    title = 'Angular4 FusionCharts Sample';
  ngOnInit() {
  }
  constructor() {
    this.dataSource = {
      "chart": {
          "caption": "Harry's SuperMart",
          "subCaption": "Top 5 stores in last month by revenue",
          "numberprefix": "$",
          "theme": "fint"
      },
      "data": [
          {
              "label": "Bakersfield Central",
              "value": "880000"
          },
          {
              "label": "Garden Groove harbour",
              "value": "730000"
          },
          {
              "label": "Los Angeles Topanga",
              "value": "590000"
          },
          {
              "label": "Compton-Rancho Dom",
              "value": "520000"
          },
          {
              "label": "Daly City Serramonte",
              "value": "330000"
          }
      ]
    };
}



}
