import { Component, OnInit } from '@angular/core';
import { WeatherMonitoringServiceService } from '../../services/weather-monitoring/weather-monitoring-service.service';
import { AppError } from '../../common/app-error';
import { BadRequestError } from '../../common/bad-request-error';
import { NotFoundError } from '../../common/not-found-error';
@Component({
  selector: 'app-weather-monitoring',
  templateUrl: './weather-monitoring.component.html',
  styleUrls: ['./weather-monitoring.component.css']
})
export class WeatherMonitoringComponent implements OnInit {
  weatherResponse: any = null;
  gaugeChartData: any;
  badRequest: 'Bad Request';
  notFound: '404 Not Found';
  constructor(private weatherService: WeatherMonitoringServiceService) { }

  ngOnInit() {
   this.renderWeather();
  }

  /**gets thedata from the service and calls construct gauge function to construct the gauge*/
  renderWeather () {
     const forecasts = 'forecasts';
     this.weatherService.getBackEndUrls()
     .subscribe(
       returnResponse => {
         this.weatherResponse = returnResponse[forecasts];
         console.log(forecasts, this.weatherResponse);
        if (this.weatherResponse == null) {
          alert();
        } else {
         this.constructGauge(this.weatherResponse[0]);
        }
      },
      (error: AppError) => {
        /**if error occurs a alert is displayed*/
          if (error instanceof BadRequestError) {
            alert(this.badRequest);
          } else if (error instanceof NotFoundError) {
            alert(this.notFound);
          } else { throw  error; }
          }
     );
  }

/**constructs the gauge with only the first data */
  constructGauge(firstObject) {
    this.gaugeChartData =  {
      chartType: 'Gauge',
      dataTable: [
        ['Label', 'Value'],
        ['Value', firstObject['ghi'] ]
      ],
      options: {
        animation: {easing: 'out'},
        width: 300, height: 300,
        greenFrom: 100, greenTo: 400,
        yellowFrom: 0, yellowTo: 100,
        redFrom: 400, redTo: 500,
        minorTicks: 5,
        min: 0, max: 500,
        majorTicks: ['0', '100', '200', '300', '400', '500'],
        greenColor: '#d0e9c6'
      }
    };
  }

}
