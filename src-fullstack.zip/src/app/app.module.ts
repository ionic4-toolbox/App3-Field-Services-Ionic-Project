import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { GenericServiceService } from './services/generic-service/generic-service.service';
import { WeatherMonitoringServiceService } from './services/weather-monitoring/weather-monitoring-service.service';
import { WeatherMonitoringComponent } from './pages/weather-monitoring/weather-monitoring.component';
import { HttpModule } from '@angular/http';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';
import { CustomCompassComponent } from './components/custom-compass/custom-compass.component';
import { CustomThermometerComponent } from './components/custom-thermometer/custom-thermometer.component';
import { FusionChartsModule } from 'angular4-fusioncharts';
import * as FusionCharts from 'fusioncharts';
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FintTheme from 'fusioncharts/themes/fusioncharts.theme.fint';

FusionChartsModule.fcRoot(FusionCharts, Charts, FintTheme);

@NgModule({
  declarations: [
    AppComponent,
    WeatherMonitoringComponent,
    CustomCompassComponent,
    CustomThermometerComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    Ng2GoogleChartsModule,
    FusionChartsModule
  ],
  providers: [GenericServiceService, WeatherMonitoringServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
