
import { Injectable } from '@angular/core';
import { ServiceProvider } from '../service/service';
import { ToastController } from 'ionic-angular/components/toast/toast-controller';
import { Http } from '@angular/http';

/*
  Generated class for the SensorRetriveServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class SensorRetriveServiceProvider extends ServiceProvider {
  constructor(public http: Http, toastCtrl: ToastController) {
    super(http,"../../assets/sensordetails.json",toastCtrl);
    console.log('Hello SensorRetriveServiceProvider Provider');
  }

}

// --proxy-server=<scheme>=<uri>[:<port>][;...] | <uri>[:<port>] | 
// --proxy-server==<scheme>"cis-india-pitc-bangalorez.proxy.corporate.ge.com:80" 