import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { ServiceProvider } from '../service/service';
import { ToastController } from 'ionic-angular';

/*
  Generated class for the PastFailureServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class PastFailureServiceProvider extends ServiceProvider{

  constructor(public http: Http , toastCtrl : ToastController) {
    super(http,"../../assets/pastFailures.json",toastCtrl);
  }

}
