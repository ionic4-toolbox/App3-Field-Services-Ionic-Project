import { Component } from '@angular/core';
import { IonicPage,  NavParams, ViewController } from 'ionic-angular';
// import { CustomLoaderComponent } from '../../components/custom-loader/custom-loader';
// import { Ng2GoogleChartsModule } from 'ng2-google-charts';
// import {RatingModule} from "ngx-rating";


/**
 * Generated class for the CustomModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-custom-modal',
  templateUrl: 'custom-modal.html',
})
export class CustomModalPage {

  showLoader:boolean=true; 
  failureList:any=null;
  sensorDetails:any=null;
  occurance:Array<number>=[] ;
  showView:string;
   lineChartData:any =  {
    chartType: 'LineChart',
    dataTable: [
      ['Year', 'Sales', 'Expenses'],
      ['2004',  1000,      400],
      ['2005',  1170,      460],
      ['2006',  660,       1120],
      ['2007',  1030,      540]
    ],
    options: {title: 'Company Performance'}
  };
  // pieChartData =  {
  //   chartType: 'LineChart',
  //   dataTable: [1,2,3,4,6,7],
  //   options: {'title': 'Tasks'},
  // };
  constructor( private navParams: NavParams, private view :ViewController ) {
  }

  ionViewDidLoad() {
    this.failureList = this.navParams.get('failureList');
    this.sensorDetails = this.navParams.get('sensorDetails');
    /**if only pastFailures is clicked*/
    if(this.failureList !=null && this.sensorDetails ==null) {
      this.renderFailureRatings();
    }
    /**if only SENSOR DETAILS is clicked*/
    else if(this.failureList ==null && this.sensorDetails !=null){
      console.log("in sensorDetails");
      this.showView="sensorDetails";
    }
    this.showLoader = !this.showLoader;
  }


  renderFailureRatings(){
   /**pusing rating to occurance array to bind it to ngModel */
   console.log("in renderFailureRatings");
   for(let i=0;i<this.failureList.length;i++){
      this.occurance.push(this.failureList[i].rating);
    }
   
    this.showView="failureReason";
    console.log("in showVcciew",this.showView);
  }



  /**returns index for ngFor which keeps track of the objects by index */
  trackByIndex(index: number, obj: any): any {
    return index;
  }
  closeModal(){
   this.view.dismiss();
  }

}
