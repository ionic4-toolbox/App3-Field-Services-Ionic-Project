import { Component, Input, Output,EventEmitter, HostListener  } from '@angular/core';
import { AppError } from '../../app/common/app-error';

/**
 * Generated class for the SingleIncidentComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */
@Component({
  selector: 'single-incident',
  templateUrl: 'single-incident.html'
})
export class SingleIncidentComponent {

  @Input("incidentAttribute") incident:IncidentInterface;
  @Input("pastFailureReasonAttribute")  pastFailureReason;
  @Output("onIncidentExpand") clickIncident = new EventEmitter<any>();
  @Output("onIncidentShrinked") shrinkIncident = new EventEmitter<any>();
  @Output("onViewPastFailureClicked") viewPastFailure = new EventEmitter<any>();
  @Output("onViewSensorDetailsCLicked") viewSensorDetails = new EventEmitter<any>();
  expand:boolean=false;
  constructor() {
  }
  onExpand(event){
    console.log("on Expand ....");
    this.expand = !this.expand;
    this.clickIncident.emit(this);
  }
  //@HostListener('blur')
  onShrink(){
    console.log("on Shrink....");
    this.expand = !this.expand;
    this.shrinkIncident.emit(this);
  }

  onViewPastFailures(){
    console.log("component onViewPastFailures  clicked");
    this.viewPastFailure.emit();
    //console.log("in component",this.pastFailureReason);
   }

  onViewSensorDetails(){
    console.log("component onViewSensorDetails  clicked");
    this.viewSensorDetails.emit();
  }
}

export interface IncidentInterface{
  incidentId:number,
  incidentName : string,
  ticketStatus : string,
  machineStatus : string,
  reason : string,
  criticality : string
}

