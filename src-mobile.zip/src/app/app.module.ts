import { NgModule, ErrorHandler, Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { Ionic2RatingModule } from 'ionic2-rating';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { NewIncidentsPage } from '../pages/new-incidents/new-incidents';
import { ProfilePage } from '../pages/profile/profile';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { HttpModule,Http } from '@angular/http';
import { IonicStorageModule } from '@ionic/storage';
import { ServiceProvider } from '../providers/service/service';
import { AppServiceProvider } from '../providers/app-service/app-service';
import { SingleIncidentComponent } from '../components/single-incident/single-incident';
import { CustomLoaderComponent } from '../components/custom-loader/custom-loader';
import { PastFailureServiceProvider } from '../providers/past-failure-service/past-failure-service';
import { CustomModalPage } from '../pages/custom-modal/custom-modal';
import { SensorRetriveServiceProvider } from '../providers/sensor-retrive-service/sensor-retrive-service';
import { Ng2GoogleChartsModule } from 'ng2-google-charts';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    TabsPage,
    NewIncidentsPage,
    ProfilePage,
    SingleIncidentComponent,
    CustomLoaderComponent,
    CustomModalPage
  ],
  imports: [
    BrowserModule,
    Ionic2RatingModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    IonicStorageModule.forRoot(),
    Ng2GoogleChartsModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,    
    HomePage,
    TabsPage,
    NewIncidentsPage,
    ProfilePage,
    SingleIncidentComponent,
    CustomModalPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    HttpModule,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    ServiceProvider,
    AppServiceProvider,
    PastFailureServiceProvider,
    SensorRetriveServiceProvider
    
  ]
})
export class AppModule {
}
