import requests
 
def datatoS4(product,workstation,imageEncoded , timestamp) :
    url = "https://m16virtual.apimanagement.hana.ondemand.com:443/ZFILE_IMPORT_SRV/ImageSet"
 
    payload = {
                "d": {
                               
                                "Workstation": "MyWS11334",
                                "Product": "LENOVO12343",
                                "Timestamp": "20180711113333",
                                "Imagebase64": "U0drZ2FTQmhiU0JUUVZBZ1FVSkJVQ0JEYjI1emRXeDBZVzUw"
                 }
     }
    headers = {
    'authorization': "Basic aG11bmRyYTpmZDQxMjM=",
    'content-type': "application/json",
    'x-csrf-token': "Fetch",
    'cache-control': "no-cache",
    'postman-token': "5f3040e9-2fe0-69ec-23a5-8e35bd771556"
    }
    s= requests.Session()
    response = s.request("GET", url, data=payload, headers=headers)
    token = response.headers['x-csrf-token']
 
    #print(token)

    payload = '{"d": {"Workstation": "'+workstation+'","Product": "'+product+'","Timestamp": "'+timestamp+'","Imagebase64": "'+imageEncoded+'"}}'
    headers1 = {
    'authorization': "Basic aG11bmRyYTpmZDQxMjM=",
    'content-type': "application/json",
    'x-csrf-token': token,
    'cache-control': "no-cache",
    
    }
 
    response1 = s.request("POST", url, data=payload, headers=headers1)
 
    #print(response1.text)
    print(response1.status_code)
    print("Data Published to S/4 Hana \n")

#a= datatoS4("IoTLab","Abhishek","abcd" , "20180711113333")
