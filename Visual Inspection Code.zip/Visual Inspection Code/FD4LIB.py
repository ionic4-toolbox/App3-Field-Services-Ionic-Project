#FD4 Motor control library ====================
import RPi.GPIO as GPIO

# FD4 Camera Capture Library ==============
import pygame,sys
from pygame.locals import *
import pygame.camera
import time
import subprocess

#import urllib2

GPIO.setmode(GPIO.BOARD)
GPIO.setup(11,GPIO.OUT)
GPIO.setup(13,GPIO.OUT)
GPIO.setwarnings(False)

#Ultrasonic pins
#4  5v       orange
#25  ground  BLACK
#29  gpio    WHITE
#30  gpio    LIGHT GREY
#31  GPIO    BROWN
#39  Ground  GREY

def check_internet():
    while True:
        ps = subprocess.Popen(['iwconfig'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        try:
           output = subprocess.check_output(('grep','ESSID'), stdin=ps.stdout)


        except subprocess.CalledProcessError:
           pass
       
        if ("off" in str(output)):
            #print(output)
            print("Please Check the network connectivity. Retrying in 10 seconds...\n")
            time.sleep(10)
        else:
            print("Network connectivity: OK")
            break
      
   
def motor(action):
   
   #GPIO.output(5,0)
   #GPIO.output(7,0)

   if action == "Start":
        #print("Motor started")
    # H L
        GPIO.output(11,1)
        GPIO.output(13,0)
 
   elif action == "Reverse":
        #print("Motor reversed")
    # H L
        GPIO.output(11,0)
        GPIO.output(13,1)
       
   elif action == "Stop":
        #print("Motor stopped")
    # L L
        GPIO.output(11,0)
        GPIO.output(13,0)
       
   else:
        print("break")
        GPIO.output(11,0)
        GPIO.output(13,0)
        

def capture(click):
   if click =="start":
        pygame.init()
        pygame.camera.init()
        cam = pygame.camera.Camera("/dev/video0",(256,256))
        cam.start()
        image= cam.get_image()
        pygame.image.save(image,'DCR123.jpg')
        cam.stop()
        return image
        
        
   else:
      print("Error in function calling")
      


   
def detectmotion():

   Pin = 29

   GPIO.setmode(GPIO.BOARD)
   GPIO.setup(Pin , GPIO.IN, pull_up_down = GPIO.PUD_UP)

   while True:
      if (0 != GPIO.input(Pin)):
           pass
           #print ('Fail');
      elif (0 == GPIO.input(Pin)):
            return

def detectmotionUltra(SetDistance):
    
 
    try:
        while True:
            dist = distance()
            #print ("Measured Distance", dist, SetDistance)
            time.sleep(0.5)
            if dist < SetDistance:
                #print("in zone")
                return

    # Reset by pressing CTRL + C
    except KeyboardInterrupt:
        GPIO.cleanup()

def distance():
    #set GPIO Pins
    GPIO_TRIGGER = 29
    GPIO_ECHO = 31
 
    #set GPIO direction (IN / OUT)
    GPIO.setup(GPIO_TRIGGER, GPIO.OUT)
    GPIO.setup(GPIO_ECHO, GPIO.IN)

    
    # set Trigger to HIGH
    GPIO.output(GPIO_TRIGGER, True)
 
    # set Trigger after 0.01ms to LOW
    time.sleep(0.00001)
    GPIO.output(GPIO_TRIGGER, False)
 
    StartTime = time.time()
    StopTime = time.time()
 
    # save StartTime
    while GPIO.input(GPIO_ECHO) == 0:
        StartTime = time.time()
 
    # save time of arrival
    while GPIO.input(GPIO_ECHO) == 1:
        StopTime = time.time()
 
    # time difference between start and arrival
    TimeElapsed = StopTime - StartTime
    # multiply with the sonic speed (34300 cm/s)
    # and divide by 2, because there and back
    distance = (TimeElapsed * 34300) / 2
 
    return distance
 
def detectFan():

   Pin = 16

   GPIO.setmode(GPIO.BOARD)
   GPIO.setup(Pin , GPIO.IN, pull_up_down = GPIO.PUD_UP)

   while True:
      if (0 == GPIO.input(Pin)):
           pass
           #print ('Fail');
      elif (0 != GPIO.input(Pin)):
            return
        
        
def start_LED(led):
    led_green = 36
    led_red = 40
    led_yellow = 38    

#led = input("enter color")

    GPIO.setup(led_green,GPIO.OUT)
    GPIO.setup(led_red,GPIO.OUT)
    GPIO.setup(led_yellow,GPIO.OUT)

    GPIO.output(led_green,False)
    GPIO.output(led_red,False)
    GPIO.output(led_yellow,False)

    if led == "green":
      print ('LED ON')
      GPIO.output(led_green,True)
    elif led == "red":
      GPIO.output(led_red,True)
    elif led == "yellow":
      GPIO.output(led_yellow,True)


    


   
        